// Radar Pracy – frontend PWA (bez frameworka, bez budowania).

const app = document.getElementById('app');
const tabs = document.getElementById('tabs');
const titleEl = document.getElementById('screen-title');

const STATUS_LABELS = {
  nowa: 'Nowa',
  przeczytana: 'Przeczytana',
  aplikowalem: 'Aplikowałem',
  rozmowa: 'Rozmowa',
  odrzucona: 'Odrzucona',
  zatrudniony: 'Zatrudniony',
  pominieta: 'Pominięta',
};
const SOURCE_STATUS = {
  dziala: ['Działa', 'ok'],
  opoznione: ['Opóźnione', 'warn'],
  blad: ['Błąd', 'bad'],
  wymaga_konfiguracji: ['Wymaga konfiguracji', 'warn'],
  reczne: ['Ręczne', ''],
  nieobslugiwane: ['Nieobsługiwane', ''],
};
const VIEWS = [
  ['pasujace', 'Pasujące'],
  ['nowe', 'Nowe'],
  ['wszystkie', 'Wszystkie'],
  ['zapisane', 'Zapisane'],
];

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function toast(msg, ms = 2800) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { t.hidden = true; }, ms);
}

class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    credentials: 'same-origin',
    headers: body !== undefined ? { 'Content-Type': 'application/json' } : {},
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let data = {};
  try { data = await res.json(); } catch { data = {}; }
  if (res.status === 401 && path !== '/api/login') {
    renderLogin();
    throw new ApiError(401, 'Zaloguj się');
  }
  if (!res.ok) throw new ApiError(res.status, data.error || `Błąd ${res.status}`);
  return data;
}

function fmtDate(iso) {
  if (!iso) return 'nie podano';
  const d = new Date(iso);
  const diff = (Date.now() - d.getTime()) / 60000;
  if (diff < 1) return 'przed chwilą';
  if (diff < 60) return `${Math.round(diff)} min temu`;
  if (diff < 24 * 60) return `${Math.round(diff / 60)} godz. temu`;
  return d.toLocaleString('pl-PL', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

function fmtSalary(j) {
  if (j.salary_min === null || j.salary_min === undefined) return 'wynagrodzenie: nie podano';
  const unit = j.salary_type === 'godzinowa' ? 'zł/h' : 'zł';
  return j.salary_max ? `${j.salary_min}–${j.salary_max} ${unit}` : `od ${j.salary_min} ${unit}`;
}

function fmtPlace(j) {
  if (!j.location_text) return '<span class="chip warn">lokalizacja do sprawdzenia</span>';
  if (j.distance_km === null || j.distance_km === undefined) return esc(j.location_text);
  return `${esc(j.location_text)} · <span class="km">${j.location_approx ? 'ok. ' : ''}${j.distance_km} km</span>`;
}

function matchChips(j) {
  if (!j.match) return '';
  if (j.match.ok) {
    const words = j.match.matched.length ? j.match.matched.join(', ') : 'wszystkie warunki';
    return `<span class="chip ok" title="Dopasowanie do ustawionych filtrów">pasuje: ${esc(words)}</span>`;
  }
  return '';
}

function setTab(name, title) {
  titleEl.textContent = title;
  tabs.hidden = false;
  for (const a of tabs.querySelectorAll('a')) a.classList.toggle('active', a.dataset.tab === name);
}

// ---------- Logowanie ----------
function renderLogin(error = '') {
  tabs.hidden = true;
  titleEl.textContent = 'Radar Pracy';
  app.innerHTML = `
    <form class="login" id="login">
      <p class="muted">Aplikacja prywatna. Podaj hasło ustawione przy wdrożeniu.</p>
      <div class="field"><span>Hasło</span><input type="password" name="password" autocomplete="current-password" required></div>
      ${error ? `<p class="err">${esc(error)}</p>` : ''}
      <button class="btn primary" type="submit">Zaloguj</button>
    </form>`;
  document.getElementById('login').addEventListener('submit', async (e) => {
    e.preventDefault();
    const password = new FormData(e.target).get('password');
    try {
      await api('/api/login', { method: 'POST', body: { password } });
      await syncSubscription();
      router();
    } catch (err) {
      renderLogin(err.message);
    }
  });
}

// ---------- Lista ofert ----------
async function renderList(params) {
  const view = params.get('widok') || 'pasujace';
  const q = params.get('q') || '';
  setTab(view === 'zapisane' ? 'zapisane' : 'lista', view === 'zapisane' ? 'Zapisane oferty' : 'Oferty');
  app.innerHTML = `
    <div class="seg">${VIEWS.map(([k, label]) => `<button data-view="${k}" class="${k === view ? 'on' : ''}">${label}</button>`).join('')}</div>
    <form class="search" id="search"><input type="search" name="q" placeholder="${view === 'zapisane' ? 'Szukaj w zapisanych…' : 'Szukaj…'}" value="${esc(q)}"></form>
    <ul class="list" id="list"><li class="muted pad">Ładowanie…</li></ul>
    <div class="pad"><button class="btn" id="more" hidden>Pokaż więcej</button></div>`;
  for (const b of app.querySelectorAll('.seg button')) {
    b.addEventListener('click', () => { location.hash = `#/?widok=${b.dataset.view}`; });
  }
  document.getElementById('search').addEventListener('submit', (e) => {
    e.preventDefault();
    const value = new FormData(e.target).get('q');
    location.hash = `#/?widok=${view}${value ? `&q=${encodeURIComponent(value)}` : ''}`;
  });
  const list = document.getElementById('list');
  const more = document.getElementById('more');
  let offset = 0;
  let first = true;
  const load = async () => {
    const data = await api(`/api/jobs?widok=${view}&offset=${offset}${q ? `&q=${encodeURIComponent(q)}` : ''}`);
    if (first) list.innerHTML = '';
    first = false;
    if (!data.jobs.length && offset === 0) {
      list.innerHTML = `<li class="muted pad">${view === 'pasujace'
        ? `Brak ofert pasujących do filtrów (promień ${data.filter.maxKm} km). Sprawdź widok „Wszystkie” albo zmień filtr w Ustawieniach.`
        : 'Brak ofert w tym widoku.'}</li>`;
    }
    list.insertAdjacentHTML('beforeend', data.jobs.map((j) => `
      <li><a class="card" href="#/oferta/${j.id}">
        <h2>${j.is_new ? '<span class="dot" title="nowa"></span> ' : ''}${esc(j.title)}${j.is_saved ? ' ★' : ''}</h2>
        <div class="row">${fmtPlace(j)}</div>
        <div class="row">${esc(fmtSalary(j))} · ${esc(fmtDate(j.published_at || j.first_seen_at))}</div>
        <div class="row">${matchChips(j)}${j.status !== 'nowa' && j.status !== 'przeczytana' ? `<span class="chip">${esc(STATUS_LABELS[j.status])}</span>` : ''}</div>
      </a></li>`).join(''));
    more.hidden = !data.hasMore;
    offset = data.nextOffset || offset;
  };
  more.addEventListener('click', () => load().catch((e) => toast(e.message)));
  await load();
}

// ---------- Szczegóły oferty ----------
async function renderJob(id) {
  setTab('lista', 'Oferta');
  app.innerHTML = '<p class="muted pad">Ładowanie…</p>';
  let j = await api(`/api/jobs/${id}`);
  if (j.status === 'nowa' || !j.is_read) {
    j = await api(`/api/jobs/${id}`, { method: 'PATCH', body: { read: true } });
  }
  const draw = () => {
    app.innerHTML = `
      <div class="section">
        <h3>${esc(j.title)}</h3>
        ${j.title_from_slug ? '<p class="small muted">Tytuł odczytany z adresu ogłoszenia – pełna treść jest w oryginale.</p>' : ''}
        <dl class="kv">
          <dt>Miejsce</dt><dd>${fmtPlace(j)}${j.location_text && j.distance_km !== null ? ' <span class="small muted">(w linii prostej od Niechobrza)</span>' : ''}</dd>
          <dt>Firma</dt><dd>${esc(j.company || 'nie podano')}</dd>
          <dt>Wynagrodzenie</dt><dd>${esc(fmtSalary(j).replace('wynagrodzenie: ', ''))}</dd>
          <dt>Umowa</dt><dd>${esc(j.contract_type || 'nie podano')}</dd>
          <dt>Telefon</dt><dd>${j.contact_phone ? `<a href="tel:${esc(j.contact_phone)}">${esc(j.contact_phone)}</a>` : 'nie podano'}</dd>
          <dt>Dodano</dt><dd>${esc(fmtDate(j.published_at))}</dd>
          <dt>Wykryto</dt><dd>${esc(fmtDate(j.first_seen_at))}</dd>
          <dt>Źródło</dt><dd>${esc(j.source)}</dd>
        </dl>
        ${j.description_summary ? `<p>${esc(j.description_summary)}</p>` : ''}
        <a class="btn primary" href="${esc(j.canonical_url)}" target="_blank" rel="noopener noreferrer">Otwórz oryginalne ogłoszenie</a>
        <button class="btn" id="save">${j.is_saved ? '★ Zapisana – usuń z zapisanych' : '☆ Zapisz ofertę'}</button>
      </div>
      <div class="section">
        <h3>Dopasowanie do ustawionych filtrów</h3>
        ${j.match ? (j.match.ok
          ? `<p>Pasuje. Słowa ze stanowisk: <b>${esc(j.match.matched.join(', ') || 'brak listy słów')}</b>.</p>`
          : `<p>Nie pasuje: ${esc(j.match.reasons.join('; '))}.</p>`) : ''}
        <p class="small muted">To wynik porównania z Twoim filtrem, a nie szansa na zatrudnienie.</p>
      </div>
      <div class="section">
        <h3>Status</h3>
        <div class="grid2">${Object.entries(STATUS_LABELS).filter(([k]) => k !== 'nowa').map(([k, label]) => `<button class="btn ${j.status === k ? 'sel primary' : ''}" data-status="${k}">${label}</button>`).join('')}</div>
      </div>
      <div class="section">
        <h3>Notatka</h3>
        <textarea id="note" placeholder="Np. dzwoniłem, oddzwonią w piątek">${esc(j.note)}</textarea>
        <button class="btn" id="save-note">Zapisz notatkę</button>
        ${j.note_updated_at ? `<p class="small muted">Zapisano: ${esc(fmtDate(j.note_updated_at))}</p>` : ''}
      </div>
      ${j.duplicates.length ? `<div class="section"><h3>To samo ogłoszenie dodane ponownie</h3>${j.duplicates.map((d) => `<p><a href="${esc(d.source_url)}" target="_blank" rel="noopener noreferrer">${esc(d.source_url)}</a></p>`).join('')}</div>` : ''}
      ${j.history.length ? `<div class="section"><h3>Historia</h3>${j.history.map((h) => `<p class="small">${esc(STATUS_LABELS[h.status] || h.status)} – ${esc(fmtDate(h.changed_at))}</p>`).join('')}</div>` : ''}`;
    document.getElementById('save').addEventListener('click', async () => {
      j = await api(`/api/jobs/${id}`, { method: 'PATCH', body: { saved: !j.is_saved } });
      toast(j.is_saved ? 'Zapisano' : 'Usunięto z zapisanych');
      draw();
    });
    for (const b of app.querySelectorAll('[data-status]')) {
      b.addEventListener('click', async () => {
        j = await api(`/api/jobs/${id}`, { method: 'PATCH', body: { status: b.dataset.status } });
        toast(`Status: ${STATUS_LABELS[j.status]}`);
        draw();
      });
    }
    document.getElementById('save-note').addEventListener('click', async () => {
      j = await api(`/api/jobs/${id}`, { method: 'PATCH', body: { note: document.getElementById('note').value } });
      toast('Notatka zapisana');
      draw();
    });
  };
  draw();
}

// ---------- Źródła ----------
async function renderSources() {
  setTab('zrodla', 'Źródła');
  const data = await api('/api/sources');
  app.innerHTML = `
    ${data.sources.map((s) => {
      const [label, cls] = SOURCE_STATUS[s.ui_status] || [s.ui_status, ''];
      return `<div class="section">
        <h3>${esc(s.name)} <span class="chip ${cls}">${esc(label)}</span></h3>
        <dl class="kv">
          <dt>Metoda</dt><dd>${esc(s.method || '—')}</dd>
          ${s.integration === 'active' ? `
            <dt>Ostatnia próba</dt><dd>${esc(fmtDate(s.last_attempt_at))}</dd>
            <dt>Ostatni sukces</dt><dd>${esc(fmtDate(s.last_success_at))}</dd>
            <dt>Ofert w kanale</dt><dd>${s.last_count} (w bazie: ${s.total_jobs})</dd>
            <dt>Błędy z rzędu</dt><dd>${s.consecutive_errors}</dd>
            ${s.last_error ? `<dt>Ostatni błąd</dt><dd class="err">${esc(s.last_error)}</dd>` : ''}` : ''}
          ${s.notes ? `<dt>Uwagi</dt><dd>${esc(s.notes)}</dd>` : ''}
        </dl>
        ${s.integration !== 'active' && s.manual_url ? `<a class="btn" href="${esc(s.manual_url)}" target="_blank" rel="noopener noreferrer">Otwórz wyszukiwanie ręcznie</a>` : ''}
      </div>`;
    }).join('')}
    <div class="section">
      <h3>Historia synchronizacji</h3>
      ${data.runs.length ? data.runs.map((r) => `<p class="small">${esc(fmtDate(r.started_at))} · <span class="chip ${r.status === 'ok' ? 'ok' : r.status === 'partial' ? 'warn' : 'bad'}">${esc(r.status)}</span> · ofert ${r.items_received}, nowych ${r.items_new}, powiadomień ${r.notifications_sent}${r.error ? ` · <span class="err">${esc(r.error)}</span>` : ''}</p>`).join('') : '<p class="muted">Jeszcze nie było synchronizacji.</p>'}
      <p class="small muted">Synchronizacja co ok. 30 minut przez GitHub Actions. Harmonogram nie jest gwarantowany – bywają opóźnienia.</p>
    </div>`;
}

// ---------- Powiadomienia ----------
function isStandalone() {
  return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
}

function urlB64ToUint8(b64) {
  const pad = '='.repeat((4 - (b64.length % 4)) % 4);
  const raw = atob((b64 + pad).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
}

async function getRegistration() {
  if (!('serviceWorker' in navigator)) return null;
  return navigator.serviceWorker.ready;
}

async function subscribePush() {
  const reg = await getRegistration();
  if (!reg || !('pushManager' in reg)) throw new Error('To urządzenie nie obsługuje Web Push. Na iPhonie otwórz aplikację z ekranu głównego.');
  const { publicKey } = await api('/api/push/key');
  let sub = await reg.pushManager.getSubscription();
  if (sub) {
    const current = sub.options && sub.options.applicationServerKey
      ? btoa(String.fromCharCode(...new Uint8Array(sub.options.applicationServerKey))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
      : null;
    if (current && current !== publicKey) {
      await sub.unsubscribe();
      sub = null;
    }
  }
  if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlB64ToUint8(publicKey) });
  await api('/api/push/subscribe', { method: 'POST', body: sub.toJSON() });
  return sub;
}

// Przy każdym otwarciu: odśwież subskrypcję na serwerze (iOS potrafi ją wymienić).
async function syncSubscription() {
  try {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    await subscribePush();
  } catch {
    /* brak sieci albo brak wsparcia – diagnostyka pokaże stan */
  }
}

async function renderSettings() {
  setTab('ustawienia', 'Ustawienia');
  const [diag, filter] = await Promise.all([api('/api/diag'), api('/api/filter')]);
  const reg = await getRegistration().catch(() => null);
  const sub = reg && reg.pushManager ? await reg.pushManager.getSubscription().catch(() => null) : null;
  const perm = 'Notification' in window ? Notification.permission : 'brak wsparcia';
  const yes = (v) => (v ? '<span class="chip ok">tak</span>' : '<span class="chip bad">nie</span>');
  const ios = /iPhone|iPad|iPod/.test(navigator.userAgent);
  app.innerHTML = `
    <div class="section">
      <h3>Powiadomienia</h3>
      ${ios && !isStandalone() ? '<p class="err">Na iPhonie powiadomienia działają tylko z ikony na ekranie głównym: w Safari stuknij Udostępnij → „Do ekranu początkowego”, potem otwórz aplikację z tej ikony.</p>' : ''}
      <button class="btn primary" id="enable">${sub ? 'Odśwież subskrypcję powiadomień' : 'Włącz powiadomienia'}</button>
      <button class="btn" id="test">Wyślij testowe powiadomienie</button>
      <button class="btn" id="test-job">Test z najnowszą ofertą (kliknij go)</button>
      ${sub ? '<button class="btn danger" id="disable">Wyłącz powiadomienia na tym urządzeniu</button>' : ''}
    </div>
    <div class="section">
      <h3>Diagnostyka</h3>
      <dl class="kv">
        <dt>Uruchomiona jako PWA</dt><dd>${yes(isStandalone())}</dd>
        <dt>Service Worker aktywny</dt><dd>${yes(reg && reg.active)}</dd>
        <dt>Subskrypcja Push (to urządzenie)</dt><dd>${yes(sub)}</dd>
        <dt>Zgoda na powiadomienia</dt><dd>${perm === 'granted' ? '<span class="chip ok">przyznana</span>' : `<span class="chip warn">${esc(perm)}</span>`}</dd>
        <dt>Aktywne subskrypcje (serwer)</dt><dd>${diag.activeSubscriptions}</dd>
        <dt>Ostatni test</dt><dd>${diag.lastTestPushAt ? esc(fmtDate(diag.lastTestPushAt)) : 'jeszcze nie'}</dd>
        <dt>Ostatnie powiadomienie o ofercie</dt><dd>${diag.lastJobPushAt ? esc(fmtDate(diag.lastJobPushAt)) : 'jeszcze nie'}</dd>
        <dt>Ostatnia synchronizacja</dt><dd>${diag.lastSync ? `${esc(fmtDate(diag.lastSync.finished_at))} (${esc(diag.lastSync.status)})` : 'jeszcze nie było'}</dd>
        <dt>Sekret synchronizacji</dt><dd>${yes(diag.ingestConfigured)}</dd>
      </dl>
    </div>
    <form class="section" id="filter">
      <h3>Filtr i powiadomienia</h3>
      <div class="field"><span>Stanowiska / słowa (jedno w linii; dopasowanie od początku słowa, bez polskich znaków)</span><textarea name="include">${esc(filter.include.join('\n'))}</textarea></div>
      <div class="field"><span>Słowa wykluczone</span><textarea name="exclude" class="short">${esc(filter.exclude.join('\n'))}</textarea></div>
      <div class="field"><span>Maksymalna odległość od Niechobrza (km)</span><input type="number" name="maxKm" min="1" max="300" value="${filter.maxKm}"></div>
      <label class="check"><input type="checkbox" name="showUnknownDistance" ${filter.showUnknownDistance ? 'checked' : ''}> Pokazuj oferty z nieznaną lokalizacją</label>
      <label class="check"><input type="checkbox" name="notifyUnknownDistance" ${filter.notifyUnknownDistance ? 'checked' : ''}> Powiadamiaj też o ofertach z nieznaną lokalizacją</label>
      <label class="check"><input type="checkbox" name="notify" ${filter.notify ? 'checked' : ''}> Powiadomienia o nowych ofertach włączone</label>
      <button class="btn primary" type="submit">Zapisz filtr</button>
    </form>
    <div class="section">
      <button class="btn danger" id="logout">Wyloguj</button>
      <p class="small muted">Punkt bazowy: Niechobrz, 36-047. Odległość liczona w linii prostej.</p>
    </div>`;

  document.getElementById('enable').addEventListener('click', async () => {
    try {
      if (!('Notification' in window)) throw new Error('Brak wsparcia powiadomień. Na iPhonie otwórz aplikację z ekranu głównego.');
      // Prośba o zgodę musi wyjść bezpośrednio z kliknięcia.
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') throw new Error('Zgoda nie została przyznana. Zmienisz to w Ustawieniach iPhone → Powiadomienia → Radar Pracy.');
      await subscribePush();
      toast('Powiadomienia włączone');
      renderSettings();
    } catch (err) {
      toast(err.message, 5000);
    }
  });
  const runTest = async (withJob) => {
    try {
      const r = await api('/api/push/test', { method: 'POST', body: { withJob } });
      const ok = r.results.filter((x) => x.ok).length;
      toast(ok ? `Wysłano (${ok}). Powiadomienie powinno przyjść za kilka sekund.` : `Nie udało się: HTTP ${r.results.map((x) => x.status).join(', ')}`, 5000);
      renderSettings();
    } catch (err) {
      toast(err.message, 5000);
    }
  };
  document.getElementById('test').addEventListener('click', () => runTest(false));
  document.getElementById('test-job').addEventListener('click', () => runTest(true));
  const disable = document.getElementById('disable');
  if (disable) {
    disable.addEventListener('click', async () => {
      await api('/api/push/unsubscribe', { method: 'POST', body: { endpoint: sub.endpoint } });
      await sub.unsubscribe();
      toast('Wyłączono na tym urządzeniu');
      renderSettings();
    });
  }
  document.getElementById('filter').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    await api('/api/filter', {
      method: 'PUT',
      body: {
        include: fd.get('include'),
        exclude: fd.get('exclude'),
        maxKm: Number(fd.get('maxKm')),
        showUnknownDistance: fd.get('showUnknownDistance') === 'on',
        notifyUnknownDistance: fd.get('notifyUnknownDistance') === 'on',
        notify: fd.get('notify') === 'on',
      },
    });
    toast('Filtr zapisany');
    renderSettings();
  });
  document.getElementById('logout').addEventListener('click', async () => {
    await api('/api/logout', { method: 'POST', body: {} });
    renderLogin();
  });
}

// ---------- Router ----------
async function router() {
  const hash = location.hash.replace(/^#/, '') || '/';
  const [path, query] = hash.split('?');
  const params = new URLSearchParams(query || '');
  window.scrollTo(0, 0);
  try {
    const job = /^\/oferta\/(\d+)$/.exec(path);
    if (job) await renderJob(Number(job[1]));
    else if (path === '/zrodla') await renderSources();
    else if (path === '/ustawienia') await renderSettings();
    else await renderList(params);
  } catch (err) {
    if (err.status === 401) return;
    app.innerHTML = `<div class="section"><p class="err">${esc(err.message)}</p><button class="btn" id="retry">Spróbuj ponownie</button></div>`;
    document.getElementById('retry').addEventListener('click', () => router());
  }
}

window.addEventListener('hashchange', router);
window.addEventListener('online', () => { document.getElementById('net').hidden = true; });
window.addEventListener('offline', () => { document.getElementById('net').hidden = false; });

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').catch(() => {});
  // Kliknięte powiadomienie, gdy aplikacja już jest otwarta.
  navigator.serviceWorker.addEventListener('message', (e) => {
    if (e.data && e.data.type === 'navigate' && typeof e.data.hash === 'string') location.hash = e.data.hash;
  });
}

(async () => {
  try {
    await api('/api/me');
    syncSubscription();
    router();
  } catch (err) {
    if (err.status !== 401) app.innerHTML = `<p class="err pad">${esc(err.message)}</p>`;
  }
})();

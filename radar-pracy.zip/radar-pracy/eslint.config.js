// Konfiguracja ESLint bez dodatkowych paczek (tylko sam eslint).
const RULES = {
  'no-undef': 'error',
  'no-unused-vars': ['error', { argsIgnorePattern: '^_', varsIgnorePattern: '^_', caughtErrors: 'none' }],
  'no-unreachable': 'error',
  'no-dupe-keys': 'error',
  'no-dupe-args': 'error',
  'no-duplicate-case': 'error',
  'no-redeclare': 'error',
  'no-const-assign': 'error',
  'no-self-assign': 'error',
  'no-cond-assign': 'error',
  'no-constant-condition': ['error', { checkLoops: false }],
  'no-empty': ['error', { allowEmptyCatch: true }],
  'no-fallthrough': 'error',
  'no-func-assign': 'error',
  'no-import-assign': 'error',
  'no-unsafe-finally': 'error',
  'no-unsafe-negation': 'error',
  'use-isnan': 'error',
  'valid-typeof': 'error',
  'eqeqeq': ['error', 'always'],
  'no-eval': 'error',
  'no-implied-eval': 'error',
  'prefer-const': 'error',
};

const shared = [
  'console', 'URL', 'URLSearchParams', 'TextEncoder', 'TextDecoder', 'crypto', 'fetch', 'Request', 'Response',
  'Headers', 'atob', 'btoa', 'setTimeout', 'clearTimeout', 'AbortSignal', 'structuredClone', 'Promise',
];
const browser = [...shared, 'window', 'document', 'navigator', 'location', 'Notification', 'FormData', 'caches'];
const worker = [...shared, 'self', 'caches', 'clients'];
const node = [...shared, 'process', 'Buffer'];
const toGlobals = (list) => Object.fromEntries(list.map((g) => [g, 'readonly']));

export default [
  { ignores: ['node_modules/', '.wrangler/', 'dist/'] },
  {
    files: ['**/*.js', '**/*.mjs'],
    languageOptions: { ecmaVersion: 2023, sourceType: 'module' },
    rules: RULES,
  },
  { files: ['src/**/*.js'], languageOptions: { globals: toGlobals(worker) } },
  { files: ['public/app.js'], languageOptions: { globals: toGlobals(browser) } },
  { files: ['public/sw.js'], languageOptions: { globals: toGlobals(worker) } },
  { files: ['sync/**/*.js', 'test/**/*.{js,mjs}', 'scripts/**/*.js', 'eslint.config.js'], languageOptions: { globals: toGlobals(node) } },
];

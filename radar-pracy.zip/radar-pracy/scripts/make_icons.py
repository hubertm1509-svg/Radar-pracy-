# Generuje ikony aplikacji (radar na ciemnym tle). Uruchom: python3 scripts/make_icons.py
from PIL import Image, ImageDraw
import math, os

OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'icons')
BG = (14, 17, 22, 255)
GREEN = (76, 195, 138, 255)

def icon(size, pad_ratio=0.0):
    s = size * 4
    img = Image.new('RGBA', (s, s), BG)
    d = ImageDraw.Draw(img)
    c = s / 2
    r_max = s * (0.40 - pad_ratio)
    for i, f in enumerate((1.0, 0.68, 0.36)):
        r = r_max * f
        w = max(2, int(s * 0.022))
        col = (GREEN[0], GREEN[1], GREEN[2], 255 - i * 50)
        d.ellipse([c - r, c - r, c + r, c + r], outline=col, width=w)
    # wiązka radaru
    a0, a1 = -60, -20
    d.pieslice([c - r_max, c - r_max, c + r_max, c + r_max], a0, a1, fill=(76, 195, 138, 110))
    ang = math.radians(a1)
    d.line([c, c, c + r_max * math.cos(ang), c + r_max * math.sin(ang)], fill=GREEN, width=max(3, int(s * 0.03)))
    # punkt = nowa oferta
    px, py = c + r_max * 0.55 * math.cos(math.radians(-40)), c + r_max * 0.55 * math.sin(math.radians(-40))
    pr = s * 0.045
    d.ellipse([px - pr, py - pr, px + pr, py + pr], fill=(242, 184, 75, 255))
    pc = s * 0.03
    d.ellipse([c - pc, c - pc, c + pc, c + pc], fill=GREEN)
    return img.resize((size, size), Image.LANCZOS)

icon(192).save(os.path.join(OUT, 'icon-192.png'))
icon(512).save(os.path.join(OUT, 'icon-512.png'))
icon(512, pad_ratio=0.08).save(os.path.join(OUT, 'icon-maskable-512.png'))
icon(180).convert('RGB').save(os.path.join(OUT, 'apple-touch-icon.png'))
print('ok')

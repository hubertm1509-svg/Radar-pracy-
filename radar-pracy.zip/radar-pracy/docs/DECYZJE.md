# Decyzje projektowe i ustawienia domyślne

## Przyjęte ustawienia (bez odpowiedzi użytkownika)

| Ustawienie | Wartość | Gdzie zmienić |
|---|---|---|
| Nazwa aplikacji | Radar Pracy | `public/manifest.webmanifest`, `public/index.html` |
| Repozytorium | `radar-pracy`, **prywatne** | GitHub |
| Logowanie | jedno hasło (`APP_PASSWORD`), sesja 90 dni w ciasteczku HttpOnly | sekret w GitHubie |
| Wygląd | ciemny motyw, duże przyciski | `public/styles.css` |
| Punkt bazowy | Niechobrz, 36-047 (49.98139, 21.86694) | `src/shared/places.js` |
| Promień | 30 km w linii prostej | Ustawienia w aplikacji |
| Stanowiska | lista z `src/shared/filter.js` | Ustawienia w aplikacji |
| Harmonogram | co 30 min (`7,37 * * * *` UTC) | `.github/workflows/sync.yml` |
| Kontakt VAPID | adres aplikacji (https) | zmienna repo `VAPID_SUBJECT` (opcjonalna) |

## Stos (zmiany względem wariantu preferowanego)

1. **Co:** jeden Cloudflare Worker z **Workers Static Assets** zamiast Pages + osobnego Workera.
   **Dlaczego:** Cloudflare zaleca Workers dla nowych projektów; jeden adres, jedno wdrożenie,
   brak problemów z CORS i ciasteczkami między domenami.
   **Ograniczenia:** jak Workers Free (niżej). **Wariant awaryjny:** pliki z `public/` da się
   wystawić na Pages bez zmian, a Workera zostawić jako API.
   **Koszt:** 0 zł.
2. **Web Push bez biblioteki:** własna implementacja RFC 8291/8292 na WebCrypto
   (`src/worker/webpush.js`), sprawdzona oficjalnym wektorem testowym z RFC 8291.
   Klucze VAPID i sekret sesji tworzą się same przy pierwszym użyciu i są trzymane w D1
   (nie trzeba ich generować ani przepisywać).
3. **Format powiadomienia:** Declarative Web Push (`web_push: 8030`). iOS 18.4+ wyświetla go
   nawet bez service workera, więc Safari nie odbiera subskrypcji za „niewyświetlone”
   powiadomienie. Service worker obsługuje go też ręcznie.
4. **Geokodowanie:** lokalny słownik ok. 50 miejscowości (`src/shared/places.js`), bez
   zewnętrznych zapytań. Miejscowość spoza słownika = „lokalizacja do sprawdzenia”,
   bez wymyślonej odległości. Dzielnice Rzeszowa mają środek miasta (oznaczone „ok.”).
   Tabela `geocoding_cache` jest przygotowana pod Nominatim (faza 3).

## Limity i koszty (stan: listopad 2026)

| Pozycja | Szacunek | Limit darmowy |
|---|---|---|
| Uruchomienia synchronizacji | 48/dzień, ~1 440/mies. | – |
| Czas zadania | 15–30 s (bez `npm install`), GitHub liczy pełną minutę | – |
| Minuty GitHub Actions (repo prywatne) | ~1 440 + wdrożenia ~3 min każde | 2 000 min/mies. |
| Requesty Workera | 48 synchronizacji + kilkaset wejść z telefonu dziennie | 100 000/dzień |
| CPU na request | parsowanie ≤600 ofert, kilka szyfrowań push | 10 ms (do sprawdzenia w logach po wdrożeniu) |
| Rozmiar D1 | ok. 2–3 KB na ofertę z indeksami; ~60 nowych ofert/dzień → ~6 MB/mies. | 500 MB |
| Zapisy D1 | nowe oferty + odświeżanie `last_seen_at` co 6 h → kilka tys./dzień | 100 000/dzień |
| Odczyty D1 | lista ofert skanuje tabelę (LIKE); 10 tys. ofert × 100 otwarć = 1 mln/dzień | 5 mln/dzień |

**Prostym językiem:**
- Harmonogram GitHuba nie jest punktualny. Typowo nowa oferta dociera po 30–60 minutach,
  czasem później, a pojedyncze uruchomienia mogą przepaść. To nie jest czas rzeczywisty.
- Przy repo prywatnym zapas minut to ok. 500 miesięcznie. Jeśli zadania zaczną trwać ponad
  minutę, trzeba będzie rzadziej synchronizować w nocy (np. co 2 h między 0 a 5).
- Po przekroczeniu limitu GitHub po prostu wstrzyma synchronizację do końca miesiąca.
  Nic nie zostanie naliczone, bo konto nie ma karty.
- Po roku (kilkadziesiąt tysięcy ofert) warto dodać archiwizację starych ofert, żeby lista
  nie zbliżała się do limitu odczytów.

## Bezpieczeństwo

- Całe `/api/*` poza `/api/health`, `/api/login` i `/api/ingest` wymaga sesji.
- `/api/ingest` wymaga osobnego `INGEST_SECRET` (hasło użytkownika tam nie działa – test e2e).
- Ochrona CSRF: ciasteczko `SameSite=Strict`, sprawdzanie nagłówka `Origin`, wymagany JSON.
- Blokada logowania: 8 błędnych prób → 15 minut przerwy.
- Subskrypcje push przyjmowane tylko dla znanych usług (Apple, Google, Mozilla, Microsoft).
- Logi nie zawierają haseł, tokenów, kluczy VAPID ani treści notatek.
- Ścisłe CSP w `public/_headers` (brak skryptów z zewnątrz i skryptów inline).

# Testy i kryteria gotowości

## Co zostało uruchomione (3.11.2026, Node 22)

- `npm test` – 18 testów jednostkowych: normalizacja, miejscowości, filtr, parser RSS
  (ISO-8859-2), normalizacja ofert, wynagrodzenie, Web Push (oficjalny wektor RFC 8291), VAPID.
- `npm run test:e2e` – 17 kroków pełnego przepływu: kod Workera w Node na prawdziwym SQLite
  (D1 to SQLite), synchronizator po HTTP, udawana usługa push, która **odszyfrowuje**
  każde powiadomienie i sprawdza podpis VAPID.
- `npm run lint` – ESLint bez błędów.
- Ręczny przegląd ekranów w Chromium w widoku iPhone 13 (logowanie, lista, oferta, status,
  notatka, źródła, ustawienia) – bez błędów JavaScript.

## Czego NIE uruchomiono

- `wrangler dev` / `wrangler deploy --dry-run` – w środowisku budowy nie było dostępu do
  rejestru npm. Wykona się w GitHub Actions przy pierwszym wdrożeniu.
- Wdrożenie na Cloudflare – brak kont (instrukcja: `docs/WDROZENIE.md`).

## Kryteria gotowości

| # | Kryterium | Stan |
|---|---|---|
| 1 | Prawdziwa oferta pojawia się w bazie | OK (e2e, dane z prawdziwego kanału) · **WYMAGA TESTU UŻYTKOWNIKA** na produkcji |
| 2 | Oferta pojawia się w PWA | OK (przeglądarka) |
| 3 | Ponowna synchronizacja nie tworzy duplikatu | OK (e2e) |
| 4 | Działa filtr odległości | OK (e2e) |
| 5 | Działa filtrowanie ofert | OK (e2e) |
| 6 | Działa zapisanie oferty | OK (e2e, przeglądarka) |
| 7 | Działa zmiana statusu | OK (e2e, przeglądarka) |
| 8 | Działa notatka | OK (e2e, przeglądarka) |
| 9 | Działa testowe powiadomienie | OK (e2e) · **WYMAGA TESTU UŻYTKOWNIKA** na iPhonie |
| 10 | Nowe ogłoszenie wysyła dokładnie jeden alert | OK (e2e) |
| 11 | Kliknięcie alertu otwiera właściwe ogłoszenie | OK (e2e: adres oferty) · **WYMAGA TESTU UŻYTKOWNIKA** |
| 12 | Aplikacja działa na iPhonie jako PWA | **WYMAGA TESTU UŻYTKOWNIKA** |
| 13 | Synchronizacja zapisuje błędy | OK (e2e) |
| 14 | Aplikacja pokazuje stan źródeł | OK (e2e, przeglądarka) |
| 15 | Instrukcja wdrożenia jest kompletna | `docs/WDROZENIE.md` |

## WYMAGA TESTU UŻYTKOWNIKA – krótko

1. Wdrożenie według `docs/WDROZENIE.md`, kroki 1–5.
2. Synchronizacja ręczna: w logu `rzeszowiak: OK`, w aplikacji lista ofert.
3. iPhone: ikona na ekranie głównym → Ustawienia → Włącz powiadomienia → Wyślij testowe.
4. **Test z najnowszą ofertą** → kliknij powiadomienie → otwiera się oferta → „Otwórz oryginalne ogłoszenie”.
5. Ustawienia → Diagnostyka: wszystkie pozycje „tak”.
6. Poczekaj na prawdziwą nową ofertę (zwykle kilka godzin) – przyjdzie jedno powiadomienie.
7. Cloudflare → Workers & Pages → radar-pracy → **Logs**: sprawdź, czy żądania `/api/ingest`
   nie przekraczają limitu CPU (błąd 1102). Jeśli tak – napisz, przeniosę wysyłkę push do GitHub Actions.

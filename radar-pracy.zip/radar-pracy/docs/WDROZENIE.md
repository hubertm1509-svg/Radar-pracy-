# Wdrożenie Radaru Pracy – krok po kroku

Całość robisz w przeglądarce, bez instalowania czegokolwiek na komputerze.
Czas: ok. 30–40 minut. Koszt: 0 zł (bez podawania karty).

Masz przygotować 5 sekretów. Zapisuj je na bieżąco w notatniku na komputerze:

| Nazwa | Skąd |
|---|---|
| `CLOUDFLARE_ACCOUNT_ID` | krok 2.3 |
| `D1_DATABASE_ID` | krok 2.4 |
| `CLOUDFLARE_API_TOKEN` | krok 2.5 |
| `APP_PASSWORD` | wymyślasz sam: hasło do aplikacji, min. 10 znaków. **Nie używaj hasła, które padło na czacie.** |
| `INGEST_SECRET` | wymyślasz sam: długi losowy ciąg, min. 24 znaki (np. 40 przypadkowych liter i cyfr). Wpisujesz go tylko w GitHubie, nigdzie nie musisz go pamiętać. |

---

## 1. GitHub

1. Wejdź na https://github.com/signup i załóż konto (darmowe).
2. Kliknij **+** (prawy górny róg) → **New repository**.
   - Repository name: `radar-pracy`
   - Zaznacz **Private**
   - Kliknij **Create repository**.
3. Na stronie nowego repozytorium kliknij link **uploading an existing file**.
4. Rozpakuj `radar-pracy.zip` na komputerze. Otwórz folder `radar-pracy`,
   zaznacz **całą jego zawartość** (Ctrl+A) i przeciągnij do okna przeglądarki.
   - Ważne: folder `.github` też musi trafić na GitHub. W Windows jest widoczny
     normalnie. Na Macu pokaż ukryte pliki skrótem Cmd+Shift+. (kropka).
5. Na dole kliknij **Commit changes**.
6. Sprawdź, że w repozytorium widać folder `.github` z plikami `deploy.yml` i `sync.yml`.

Pierwsze wdrożenie uruchomi się samo i **zakończy się błędem**, bo nie ma jeszcze sekretów. To normalne.

## 2. Cloudflare

1. Wejdź na https://dash.cloudflare.com/sign-up i załóż konto (darmowe).
2. W menu po lewej wybierz **Workers & Pages**. Jeśli Cloudflare poprosi
   o wybranie subdomeny `*.workers.dev`, wpisz dowolną krótką nazwę, np. `hubert`.
   Adres aplikacji będzie wtedy: `https://radar-pracy.hubert.workers.dev`.
3. **Account ID:** na stronie **Workers & Pages** po prawej jest pole
   „Account ID” → skopiuj → to `CLOUDFLARE_ACCOUNT_ID`.
4. **Baza D1:** menu **Storage & Databases** → **D1 SQL Database** → **Create**.
   - Name: `radar-pracy` (dokładnie tak)
   - Kliknij **Create**. Na stronie bazy skopiuj **Database ID** → to `D1_DATABASE_ID`.
5. **Token API:** kliknij ikonę konta (prawy górny róg) → **Profile** → **API Tokens**
   → **Create Token** → przy szablonie **Edit Cloudflare Workers** kliknij **Use template**.
   - W sekcji **Permissions** kliknij **+ Add more** i dodaj:
     **Account** → **D1** → **Edit**.
   - Account Resources: twoje konto. Zone Resources: **All zones**.
   - **Continue to summary** → **Create Token** → skopiuj token (pokazuje się raz)
     → to `CLOUDFLARE_API_TOKEN`.

## 3. Sekrety w GitHubie

W repozytorium: **Settings** → **Secrets and variables** → **Actions**.

1. Zakładka **Secrets** → **New repository secret**. Dodaj po kolei 5 sekretów
   z tabeli na górze (nazwa dokładnie jak w tabeli, wartość z notatnika).

## 4. Pierwsze wdrożenie

1. W repozytorium zakładka **Actions** → po lewej **Wdrożenie** → **Run workflow** → **Run workflow**.
2. Poczekaj 2–3 minuty, aż pojawi się zielony znaczek.
3. Otwórz zadanie i krok **Wdróż Workera**. W logu jest adres w stylu
   `https://radar-pracy.TWOJA-NAZWA.workers.dev` – skopiuj go.
4. Wróć do **Settings** → **Secrets and variables** → **Actions** → zakładka **Variables**
   → **New repository variable**:
   - Name: `WORKER_URL`
   - Value: adres z punktu 3 (bez ukośnika na końcu).

## 5. Pierwsza synchronizacja (bez powiadomień)

1. **Actions** → **Synchronizacja ofert** → **Run workflow**.
2. Po ok. 30 sekundach w logu zobaczysz np. `rzeszowiak: OK, ofert 200` i
   `pierwsza synchronizacja (bez powiadomień): rzeszowiak`.
   Istniejące ogłoszenia trafiają do bazy bez alertów.
3. Od teraz synchronizacja uruchamia się sama co ok. 30 minut.

## 6. iPhone

1. Otwórz adres aplikacji w **Safari** (nie w Chrome).
2. Zaloguj się hasłem `APP_PASSWORD`.
3. Stuknij **Udostępnij** (kwadrat ze strzałką) → **Do ekranu początkowego** →
   upewnij się, że przełącznik **Otwórz jako aplikację webową** jest włączony → **Dodaj**.
4. Zamknij Safari i otwórz **Radar Pracy z ikony na ekranie głównym**.
   Zaloguj się jeszcze raz (aplikacja z ekranu głównego ma osobne ciasteczka).
5. **Ustawienia** → **Włącz powiadomienia** → **Zezwól**.
6. **Wyślij testowe powiadomienie** → powinno przyjść w kilka sekund.
7. **Test z najnowszą ofertą** → kliknij powiadomienie → powinna otworzyć się ta oferta
   → przycisk **Otwórz oryginalne ogłoszenie** otwiera Rzeszowiak.pl.

## Gdy coś nie działa

| Objaw | Co zrobić |
|---|---|
| Wdrożenie: „Brakuje sekretów” | Sprawdź nazwy sekretów (wielkość liter ma znaczenie). |
| Wdrożenie: błąd przy „Migracje bazy D1” | Token nie ma uprawnienia D1 Edit albo `D1_DATABASE_ID` jest błędne. |
| Synchronizacja: „Brak WORKER_URL” | Dodaj zmienną z kroku 4.4 (zakładka **Variables**, nie Secrets). |
| Synchronizacja: HTTP 401 | `INGEST_SECRET` zmieniony po wdrożeniu – uruchom ponownie **Wdrożenie**. |
| Brak przycisku zgody / „brak wsparcia” | Aplikacja otwarta w Safari zamiast z ikony na ekranie głównym. |
| Test wysłany, ale nic nie przychodzi | iPhone: **Ustawienia → Powiadomienia → Radar Pracy** – włącz. Sprawdź tryb Skupienia. |
| Po dłuższej przerwie powiadomienia ucichły | Otwórz aplikację z ikony – subskrypcja odświeża się sama przy każdym otwarciu. |

## Aktualizacje kodu

Każda zmiana plików w gałęzi `main` uruchamia **Wdrożenie** automatycznie
(testy → migracje bazy → wdrożenie). Dane w bazie zostają.

# Macierz źródeł ofert (weryfikacja: 3 listopada 2026)

Kolejność metod: oficjalne API → RSS → oficjalne alerty → e-mail → publiczny endpoint →
strona zgodna z regulaminem → HTML (ostateczność). Bez obchodzenia CAPTCHA, logowania,
blokad, bez proxy i przeglądarek headless.

| Źródło | Status w aplikacji | Metoda | Uwagi |
|---|---|---|---|
| Rzeszowiak.pl | **działa** (`active`) | 3 oficjalne kanały RSS: Zatrudnię, agencje, dodatkowa | Kanał podaje adres, datę i często krótki tytuł; opis bywa pusty. Kodowanie ISO-8859-2. Sprawdzone 3.11.2026 na prawdziwym kanale. |
| Pracuj.pl | `official_alert` | alert e-mail w serwisie | Brak publicznego API/RSS. Link do wyszukiwania w aplikacji. |
| Praca.pl | `manual_source` | ręcznie | Nie znaleziono RSS/API. |
| JOBS.pl | `manual_source` | ręcznie | j.w. |
| OLX Praca | `official_alert` | obserwowane wyszukiwanie w aplikacji OLX | Partner API OLX nie pozwala czytać cudzych ogłoszeń. |
| ePraca (CBOP) | `requires_configuration` | WebService SOAP | Wymaga nazwy partnera od ministerstwa; usługa działa 17:00–07:00. Faza 5. |
| PUP Rzeszów | `requires_configuration` | przez ePraca | Oferty PUP są w bazie CBOP. |
| Aplikuj.pl | `manual_source` | ręcznie | Nie znaleziono RSS/API. |
| Indeed | `official_alert` | alert e-mail Indeed | Publiczne API wycofane. |
| Lento.pl | `manual_source` | ręcznie | Nie znaleziono RSS/API. |
| Strony karier | `requires_configuration` | feedy ATS | Trzeba wskazać konkretnych pracodawców. |
| Lokalne portale | `requires_configuration` | RSS do weryfikacji | Np. e-rzeszowiak.pl – sprawdzić regulamin i RSS. |

## Jak dodać kolejne źródło

1. Adapter w `sync/adapters/<nazwa>.js` zwracający oferty w tym samym formacie co Rzeszowiak.
2. Wywołanie w `sync/run.js` (osobny element `sources`).
3. Zmiana `integration` na `active` w nowej migracji `migrations/000X_*.sql`.
4. Fixture i test w `test/`.

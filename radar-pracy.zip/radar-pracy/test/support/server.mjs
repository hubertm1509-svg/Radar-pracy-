// Serwer HTTP w Node, który uruchamia kod Workera z lokalnym D1 i plikami public.
// Użycie do podglądu: APP_PASSWORD=... INGEST_SECRET=... node test/support/server.mjs
import { createServer } from 'node:http';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { LocalD1, localAssets } from './d1.mjs';
import worker from '../../src/worker/index.js';

const root = fileURLToPath(new URL('../../', import.meta.url));

export async function startServer(envOverrides = {}, { port = 0, dbPath = ':memory:' } = {}) {
  const DB = new LocalD1(dbPath);
  DB.migrate(`${root}migrations`);
  const env = { DB, ASSETS: localAssets(`${root}public`), ...envOverrides };
  const server = createServer(async (req, res) => {
    const chunks = [];
    for await (const c of req) chunks.push(c);
    const body = chunks.length ? Buffer.concat(chunks) : undefined;
    const url = `http://${req.headers.host}${req.url}`;
    const headers = new Headers();
    for (const [k, v] of Object.entries(req.headers)) if (typeof v === 'string') headers.set(k, v);
    const request = new Request(url, { method: req.method, headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : body });
    try {
      const response = await worker.fetch(request, env);
      const out = {};
      response.headers.forEach((v, k) => { out[k] = v; });
      res.writeHead(response.status, out);
      res.end(Buffer.from(await response.arrayBuffer()));
    } catch (err) {
      res.writeHead(500);
      res.end(String(err));
    }
  });
  await new Promise((r) => server.listen(port, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  return { server, base, env, DB };
}

if (import.meta.url === pathToFileURL(process.argv[1] || '').href) {
  const { base } = await startServer({
    APP_PASSWORD: process.env.APP_PASSWORD,
    INGEST_SECRET: process.env.INGEST_SECRET,
  }, { port: Number(process.env.PORT) || 8787, dbPath: process.env.DB_PATH || 'local.sqlite' });
  console.log(`Radar Pracy (podgląd lokalny): ${base}`);
}

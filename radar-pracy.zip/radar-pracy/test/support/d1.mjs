// Lokalny zamiennik Cloudflare D1 na wbudowanym w Node SQLite (node:sqlite).
// D1 to SQLite, więc zapytania (json_each, RETURNING, upsert) działają tak samo.
// Używany w teście end-to-end i lokalnym serwerze podglądu.

import { DatabaseSync } from 'node:sqlite';
import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

const conv = (v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v);
const plain = (rows) => rows.map((r) => ({ ...r }));

class Statement {
  constructor(db, sql, params = []) {
    this.db = db;
    this.sql = sql;
    this.params = params;
  }

  bind(...params) {
    return new Statement(this.db, this.sql, params.map(conv));
  }

  _all() {
    return plain(this.db.prepare(this.sql).all(...this.params));
  }

  async first(column) {
    const row = this._all()[0] ?? null;
    return row && column ? row[column] : row;
  }

  async all() {
    return { success: true, results: this._all(), meta: {} };
  }

  async run() {
    const r = this.db.prepare(this.sql).run(...this.params);
    return { success: true, results: [], meta: { changes: Number(r.changes), last_row_id: Number(r.lastInsertRowid) } };
  }
}

export class LocalD1 {
  constructor(path = ':memory:') {
    this.db = new DatabaseSync(path);
    this.db.exec('PRAGMA foreign_keys = ON');
  }

  prepare(sql) {
    return new Statement(this.db, sql);
  }

  async batch(statements) {
    this.db.exec('BEGIN');
    try {
      const out = statements.map((s) => ({ success: true, results: s._all(), meta: {} }));
      this.db.exec('COMMIT');
      return out;
    } catch (err) {
      this.db.exec('ROLLBACK');
      throw err;
    }
  }

  async exec(sql) {
    this.db.exec(sql);
  }

  migrate(dir) {
    this.db.exec('CREATE TABLE IF NOT EXISTS _local_migrations (name TEXT PRIMARY KEY)');
    const done = new Set(this.db.prepare('SELECT name FROM _local_migrations').all().map((r) => r.name));
    for (const f of readdirSync(dir).filter((n) => n.endsWith('.sql')).sort()) {
      if (done.has(f)) continue;
      this.db.exec(readFileSync(join(dir, f), 'utf8'));
      this.db.prepare('INSERT INTO _local_migrations (name) VALUES (?)').run(f);
    }
  }
}

// Zamiennik env.ASSETS (Workers Static Assets) – pliki z katalogu public.
export function localAssets(dir) {
  const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
  return {
    async fetch(request) {
      let p = new URL(request.url).pathname;
      if (p === '/') p = '/index.html';
      if (p.includes('..')) return new Response('Bad request', { status: 400 });
      try {
        const body = readFileSync(join(dir, p));
        const ext = p.slice(p.lastIndexOf('.'));
        return new Response(body, { headers: { 'Content-Type': types[ext] || 'application/octet-stream' } });
      } catch {
        return new Response('Not found', { status: 404 });
      }
    },
  };
}

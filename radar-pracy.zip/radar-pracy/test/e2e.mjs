// Test end-to-end pełnego przepływu:
// oferta z RSS → synchronizator → /api/ingest → baza → API/PWA → nowa oferta →
// Web Push (zaszyfrowany, podpisany VAPID) → adres konkretnej oferty → oryginalne ogłoszenie.
// Worker działa w Node na prawdziwym SQLite (D1 = SQLite); usługa push jest udawana
// lokalnie i odszyfrowuje każde powiadomienie kluczami "telefonu".

import { createServer } from 'node:http';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import { startServer } from './support/server.mjs';
import { runSync } from '../sync/run.js';
import { b64uDecode, b64uEncode } from '../src/worker/webpush.js';
import { decryptPayload } from './support/push-decrypt.mjs';

const fx = (n) => fileURLToPath(new URL(`./fixtures/${n}`, import.meta.url));
const EMPTY = fx('rzeszowiak-empty.xml');
const feeds = (main) => ({ zatrudnie: main, agencje: EMPTY, dodatkowa: EMPTY });

const INGEST_SECRET = 'test-ingest-secret-0123456789abcdef';
const PASSWORD = 'testowe-haslo-123';
let passed = 0;
async function step(name, fn) {
  await fn();
  passed++;
  console.log(`ok ${passed} - ${name}`);
}

// ---- Udawana usługa push (jak web.push.apple.com) ----
const devices = new Map(); // nazwa -> { keys, auth, received: [], mode }
const pushServer = createServer(async (req, res) => {
  const name = req.url.split('/').pop();
  const dev = devices.get(name);
  const chunks = [];
  for await (const c of req) chunks.push(c);
  if (!dev) { res.writeHead(404); res.end(); return; }
  if (dev.mode === 'gone') { res.writeHead(410); res.end('expired'); return; }
  if (dev.failsLeft > 0) { dev.failsLeft--; res.writeHead(500); res.end('temporary'); return; }
  // Weryfikacja nagłówków i podpisu VAPID
  const auth = req.headers.authorization || '';
  const m = /^vapid t=([^,]+), k=(.+)$/.exec(auth);
  assert.ok(m, 'nagłówek VAPID');
  assert.equal(req.headers['content-encoding'], 'aes128gcm');
  assert.ok(Number(req.headers.ttl) > 0);
  const [h, c, s] = m[1].split('.');
  const pub = await crypto.subtle.importKey('raw', b64uDecode(m[2]), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
  const valid = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, pub, b64uDecode(s), new TextEncoder().encode(`${h}.${c}`));
  assert.ok(valid, 'podpis VAPID');
  const text = await decryptPayload(new Uint8Array(Buffer.concat(chunks)), dev.keys, dev.auth);
  dev.received.push(JSON.parse(text));
  res.writeHead(201);
  res.end();
});
await new Promise((r) => pushServer.listen(0, '127.0.0.1', r));
const pushBase = `http://127.0.0.1:${pushServer.address().port}`;

async function newDevice(name, mode = 'ok') {
  const keys = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const auth = crypto.getRandomValues(new Uint8Array(16));
  const dev = { keys, auth, received: [], mode };
  devices.set(name, dev);
  const p256dh = b64uEncode(new Uint8Array(await crypto.subtle.exportKey('raw', keys.publicKey)));
  return { dev, subscription: { endpoint: `${pushBase}/push/${name}`, keys: { p256dh, auth: b64uEncode(auth) } } };
}

// ---- Aplikacja ----
const { server, base, DB } = await startServer({
  APP_PASSWORD: PASSWORD,
  INGEST_SECRET,
  ALLOW_TEST_PUSH_ENDPOINT: '1',
  VAPID_SUBJECT: 'mailto:test@example.com',
});

let cookie = '';
async function call(path, { method = 'GET', body, headers = {}, auth = true } = {}) {
  const res = await fetch(base + path, {
    method,
    headers: {
      ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      Origin: base,
      ...(auth && cookie ? { Cookie: cookie } : {}),
      ...headers,
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data, headers: res.headers };
}
const sync = (main, extra = {}) => runSync({ workerUrl: base, secret: INGEST_SECRET, fixtures: feeds(main), ...extra });
const count = async (sql, ...p) => (await DB.prepare(sql).bind(...p).first()).n;

try {
  await step('PWA: strona, manifest i service worker są serwowane', async () => {
    for (const p of ['/', '/manifest.webmanifest', '/sw.js', '/app.js', '/icons/icon-192.png']) {
      const r = await fetch(base + p);
      assert.equal(r.status, 200, p);
    }
  });

  await step('prywatne API wymaga logowania', async () => {
    assert.equal((await call('/api/jobs', { auth: false })).status, 401);
    assert.equal((await call('/api/login', { method: 'POST', body: { password: 'zle' }, auth: false })).status, 401);
    const ok = await call('/api/login', { method: 'POST', body: { password: PASSWORD }, auth: false });
    assert.equal(ok.status, 200);
    const setCookie = ok.headers.get('set-cookie');
    assert.match(setCookie, /HttpOnly/);
    assert.match(setCookie, /SameSite=Strict/);
    cookie = setCookie.split(';')[0];
    assert.equal((await call('/api/me')).status, 200);
  });

  await step('ingest wymaga osobnego sekretu serwerowego', async () => {
    const r = await fetch(`${base}/api/ingest`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${PASSWORD}` }, body: '{}' });
    assert.equal(r.status, 401, 'hasło użytkownika nie działa jako sekret synchronizacji');
  });

  await step('pierwsza synchronizacja: zapis prawdziwych ofert bez powiadomień', async () => {
    const r = await sync(fx('rzeszowiak-a.xml'));
    assert.deepEqual(r.response.baseline, ['rzeszowiak']);
    assert.equal(r.response.received, 11);
    assert.equal(r.response.newJobs, 10, '11 ogłoszeń, w tym 1 ponowne dodanie tego samego');
    assert.equal(r.response.notificationsSent, 0);
    assert.equal(await count('SELECT COUNT(*) n FROM jobs'), 11);
    assert.equal(await count('SELECT COUNT(*) n FROM jobs WHERE duplicate_of IS NOT NULL'), 1);
    assert.equal(await count("SELECT COUNT(*) n FROM jobs WHERE title LIKE 'Firma amlux%' AND duplicate_of IS NULL"), 2, 'dwa ogłoszenia tej samej firmy bez tytułu nie są łączone');
  });

  const phone = await newDevice('iphone');
  await step('subskrypcja push zapisana w bazie', async () => {
    const r = await call('/api/push/subscribe', { method: 'POST', body: phone.subscription });
    assert.equal(r.status, 200);
    const again = await call('/api/push/subscribe', { method: 'POST', body: phone.subscription });
    assert.equal(again.status, 200);
    assert.equal(await count('SELECT COUNT(*) n FROM push_subscriptions WHERE active = 1'), 1);
    const bad = await call('/api/push/subscribe', { method: 'POST', body: { ...phone.subscription, endpoint: 'https://evil.example.com/x' } });
    assert.equal(bad.status, 400);
  });

  await step('ponowna synchronizacja nie tworzy duplikatów ani powiadomień', async () => {
    const r = await sync(fx('rzeszowiak-a.xml'));
    assert.equal(r.response.newJobs, 0);
    assert.equal(await count('SELECT COUNT(*) n FROM jobs'), 11);
    assert.equal(phone.dev.received.length, 0);
  });

  let mechanicId;
  await step('nowa pasująca oferta wysyła dokładnie jedno powiadomienie', async () => {
    const r = await sync(fx('rzeszowiak-b.xml'));
    assert.equal(r.response.newJobs, 2);
    assert.equal(r.response.notificationsSent, 1, 'mechanik w Boguchwale tak, nauczyciel nie');
    assert.equal(phone.dev.received.length, 1);
    const msg = phone.dev.received[0];
    assert.equal(msg.web_push, 8030);
    assert.match(msg.notification.title, /Mechanik samochodowy/);
    assert.match(msg.notification.body, /Boguchwała \(5\.6 km\)/);
    const m = new RegExp(`^${base}/#/oferta/(\\d+)$`).exec(msg.notification.navigate);
    assert.ok(m, msg.notification.navigate);
    mechanicId = Number(m[1]);
  });

  await step('kliknięcie powiadomienia → właściwa oferta → link do oryginału', async () => {
    const r = await call(`/api/jobs/${mechanicId}`);
    assert.equal(r.status, 200);
    assert.equal(r.data.canonical_url, 'https://www.rzeszowiak.pl/zatrudnie-mechanika-samochodowego-w-boguchwale-55312001');
    assert.equal(r.data.location_text, 'Boguchwała');
    assert.equal(r.data.match.ok, true);
    assert.equal(r.data.source_urls.length, 1);
  });

  await step('powtórzona synchronizacja i ten sam runId nie wysyłają drugiego alertu', async () => {
    await sync(fx('rzeszowiak-b.xml'));
    const dry = await sync(fx('rzeszowiak-b.xml'), { dryRun: true });
    const send = () => fetch(`${base}/api/ingest`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${INGEST_SECRET}` }, body: JSON.stringify(dry.payload) }).then((x) => x.json());
    await send();
    const second = await send();
    assert.equal(second.duplicateRun, true);
    assert.equal(phone.dev.received.length, 1);
    assert.equal(await count("SELECT COUNT(*) n FROM notifications WHERE kind = 'job' AND status = 'sent'"), 1);
  });

  await step('błąd źródła jest zapisany, a oferty zostają', async () => {
    const r = await runSync({ workerUrl: base, secret: INGEST_SECRET, fixtures: { zatrudnie: null, agencje: null, dodatkowa: null } });
    assert.equal(r.response.status, 'error');
    assert.equal(await count('SELECT COUNT(*) n FROM jobs'), 13);
    const s = await call('/api/sources');
    const rz = s.data.sources.find((x) => x.source === 'rzeszowiak');
    assert.equal(rz.ui_status, 'blad');
    assert.equal(rz.consecutive_errors, 1);
    assert.match(rz.last_error, /zatrudnie/);
    assert.equal(s.data.runs[0].status, 'error');
    await sync(fx('rzeszowiak-b.xml'));
    const after = (await call('/api/sources')).data.sources.find((x) => x.source === 'rzeszowiak');
    assert.equal(after.ui_status, 'dziala');
    const pracuj = s.data.sources.find((x) => x.source === 'pracuj');
    assert.equal(pracuj.ui_status, 'reczne');
    assert.equal(s.data.sources.find((x) => x.source === 'epraca').ui_status, 'wymaga_konfiguracji');
  });

  await step('lista ofert: filtr stanowisk i odległości', async () => {
    const pas = (await call('/api/jobs?widok=pasujace')).data.jobs;
    assert.ok(pas.some((j) => j.id === mechanicId));
    assert.ok(!pas.some((j) => /Nauczyciel/.test(j.title)));
    assert.ok(!pas.some((j) => /SZCZECIN/.test(j.title)), 'Szczecin poza promieniem');
    const all = (await call('/api/jobs?widok=wszystkie')).data.jobs;
    assert.equal(all.length, 12, '13 ofert minus 1 duplikat');
    const f = (await call('/api/filter')).data;
    await call('/api/filter', { method: 'PUT', body: { ...f, maxKm: 5 } });
    const near = (await call('/api/jobs?widok=pasujace')).data.jobs;
    assert.ok(!near.some((j) => j.id === mechanicId), 'Boguchwała 5.6 km > 5 km');
    await call('/api/filter', { method: 'PUT', body: { ...f, maxKm: 30 } });
  });

  await step('status, zapisanie, notatka i wyszukiwanie zapisanych', async () => {
    await call(`/api/jobs/${mechanicId}`, { method: 'PATCH', body: { read: true } });
    let r = await call(`/api/jobs/${mechanicId}`, { method: 'PATCH', body: { status: 'aplikowalem', saved: true, note: 'Dzwonić w piątek' } });
    assert.equal(r.data.status, 'aplikowalem');
    assert.equal(r.data.is_saved, 1);
    assert.equal(r.data.note, 'Dzwonić w piątek');
    assert.equal(r.data.history[0].status, 'aplikowalem');
    r = await call('/api/jobs?widok=zapisane&q=mechanik');
    assert.deepEqual(r.data.jobs.map((j) => j.id), [mechanicId]);
    r = await call('/api/jobs?widok=zapisane&q=spawacz');
    assert.equal(r.data.jobs.length, 0);
    assert.equal((await call(`/api/jobs/${mechanicId}`, { method: 'PATCH', body: { status: 'cokolwiek' } })).status, 400);
  });

  await step('ochrona przed CSRF (obce Origin)', async () => {
    const r = await call(`/api/jobs/${mechanicId}`, { method: 'PATCH', body: { saved: false }, headers: { Origin: 'https://evil.example.com' } });
    assert.equal(r.status, 403);
  });

  await step('testowe powiadomienie i test z ofertą', async () => {
    const r = await call('/api/push/test', { method: 'POST', body: {} });
    assert.equal(r.status, 200);
    assert.equal(r.data.results[0].ok, true);
    const last = phone.dev.received.at(-1);
    assert.match(last.notification.title, /test/i);
    const r2 = await call('/api/push/test', { method: 'POST', body: { withJob: true } });
    assert.equal(r2.data.results[0].ok, true);
    assert.match(phone.dev.received.at(-1).notification.navigate, /#\/oferta\/\d+$/);
    const diag = (await call('/api/diag')).data;
    assert.ok(diag.lastTestPushAt);
    assert.ok(diag.lastJobPushAt);
    assert.equal(diag.activeSubscriptions, 1);
  });

  await step('wygasła subskrypcja (410) zostaje wyłączona', async () => {
    const old = await newDevice('stary-telefon', 'gone');
    await call('/api/push/subscribe', { method: 'POST', body: old.subscription });
    assert.equal(await count('SELECT COUNT(*) n FROM push_subscriptions WHERE active = 1'), 2);
    await call('/api/push/test', { method: 'POST', body: {} });
    assert.equal(await count('SELECT COUNT(*) n FROM push_subscriptions WHERE active = 1'), 1);
  });

  await step('wiele nowych ofert naraz: 4 pojedyncze + 1 zbiorcze, bez lawiny', async () => {
    const before = phone.dev.received.length;
    const dir = mkdtempSync(join(tmpdir(), 'rp-'));
    const items = Array.from({ length: 8 }, (_, i) => `<item rdf:about="http://www.rzeszowiak.pl/magazynier-rzeszow-${5531300 + i}0">
<dc:date>2026-11-03T06:0${i}:00+01:00</dc:date><dc:creator>Magazynier ${i + 1} Rzeszow&lt;rzeszowiak.pl&gt;</dc:creator>
<title>Magazynier ${i + 1} Rzeszow ... </title><link>http://www.rzeszowiak.pl/magazynier-rzeszow-${5531300 + i}0</link><description></description></item>`).join('\n');
    const file = join(dir, 'many.xml');
    writeFileSync(file, `<?xml version="1.0" encoding="ISO-8859-2"?><rdf:RDF xmlns="http://purl.org/rss/1.0/" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:dc="http://purl.org/dc/elements/1.1/">${items}</rdf:RDF>`);
    const r = await sync(file);
    assert.equal(r.response.newJobs, 8);
    const got = phone.dev.received.slice(before);
    assert.equal(got.length, 5);
    assert.match(got[4].notification.title, /Jeszcze 4 nowych ofert/);
    await sync(file);
    assert.equal(phone.dev.received.length, before + 5, 'brak powtórek przy kolejnej synchronizacji');
  });

  await step('nieudane powiadomienie nie jest oznaczane jako wysłane i jest ponawiane', async () => {
    const flaky = await newDevice('telefon2');
    flaky.dev.failsLeft = 2; // pierwsza próba i natychmiastowe ponowienie kończą się błędem
    await call('/api/push/subscribe', { method: 'POST', body: flaky.subscription });
    const dir = mkdtempSync(join(tmpdir(), 'rp-'));
    const file = join(dir, 'one.xml');
    writeFileSync(file, `<?xml version="1.0" encoding="ISO-8859-2"?><rdf:RDF xmlns="http://purl.org/rss/1.0/" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:dc="http://purl.org/dc/elements/1.1/">
<item rdf:about="http://www.rzeszowiak.pl/kierowca-kurier-tyczyn-55314000"><dc:date>2026-11-03T07:00:00+01:00</dc:date><dc:creator>Kierowca kurier Tyczyn&lt;rzeszowiak.pl&gt;</dc:creator><title>Kierowca kurier Tyczyn ... </title><link>http://www.rzeszowiak.pl/kierowca-kurier-tyczyn-55314000</link><description></description></item></rdf:RDF>`);
    await sync(file);
    assert.equal(flaky.dev.received.length, 0);
    assert.equal(await count("SELECT COUNT(*) n FROM notifications WHERE status = 'failed' AND attempts = 2"), 1);
    await sync(file);
    assert.equal(flaky.dev.received.length, 1, 'ponowienie przy następnej synchronizacji');
    assert.equal(await count("SELECT COUNT(*) n FROM notifications WHERE status = 'failed'"), 0);
  });

  console.log(`\n# e2e: ${passed} kroków OK`);
} catch (err) {
  console.error(`not ok ${passed + 1}`);
  console.error(err);
  process.exitCode = 1;
} finally {
  server.close();
  pushServer.close();
}

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { decodeXml, parseFeed } from '../../sync/rss.js';
import { cleanTitle, extractSalary, parseRzeszowiak } from '../../sync/adapters/rzeszowiak.js';
import { collectRzeszowiak } from '../../sync/run.js';

const fixture = (name) => new URL(`../fixtures/${name}`, import.meta.url);

test('dekodowanie ISO-8859-2 z deklaracji XML', async () => {
  const xml = decodeXml(await readFile(fixture('rzeszowiak-b.xml')));
  assert.match(xml, /Boguchwała/);
});

test('parser RSS 1.0 (RDF) Rzeszowiaka', async () => {
  const xml = decodeXml(await readFile(fixture('rzeszowiak-a.xml')));
  const items = parseFeed(xml);
  assert.equal(items.length, 11);
  assert.equal(items[0].creator, 'SPAWACZ MIG/MAG (135/136)<rzeszowiak.pl>');
  assert.match(items[0].link, /55311115$/);
  assert.equal(items[0].date, '2026-11-02T22:16:01+01:00');
});

test('normalizacja ofert: id, https, tytuł, brak zmyślonych danych', async () => {
  const xml = decodeXml(await readFile(fixture('rzeszowiak-a.xml')));
  const jobs = parseRzeszowiak(xml, 'zatrudnie', '2026-11-03T04:00:00.000Z');
  const weld = jobs.find((j) => j.sourceId === '55311115');
  assert.equal(weld.title, 'SPAWACZ MIG/MAG (135/136)');
  assert.equal(weld.canonicalUrl.startsWith('https://www.rzeszowiak.pl/'), true);
  assert.equal(weld.company, null);
  assert.equal(weld.salaryMin, null);
  assert.equal(weld.publishedAt, '2026-11-02T21:16:01.000Z');

  const jaro = jobs.find((j) => j.sourceId === '55310557');
  assert.equal(jaro.titleFromSlug, true);
  assert.equal(jaro.locationText, 'Niechobrz');
  assert.equal(jaro.distanceKm, 0);

  const helper = jobs.find((j) => j.sourceId === '55311033');
  assert.deepEqual([helper.salaryMin, helper.salaryMax, helper.salaryType], [30, 40, 'godzinowa']);

  const bruk = jobs.find((j) => j.sourceId === '55310356');
  assert.equal(bruk.contactPhone, '453316887');
  assert.equal(bruk.locationText, null);
  assert.equal(bruk.distanceKm, null);
});

test('extractSalary nie zgaduje bez "zł"', () => {
  assert.equal(extractSalary('wynagrodzenie 6 000 8 000'), null);
  assert.deepEqual(extractSalary('od 5000 zł brutto'), { min: 5000, max: null, type: 'miesięczna' });
  assert.deepEqual(extractSalary('4500-5500 zł'), { min: 4500, max: 5500, type: 'miesięczna' });
  assert.equal(extractSalary('5 zł'), null);
});

test('cleanTitle usuwa dopisek portalu i wielokropek', () => {
  assert.equal(cleanTitle('Kierowca C+E ... '), 'Kierowca C+E');
  assert.equal(cleanTitle('Brukarz<rzeszowiak.pl>'), 'Brukarz');
});

test('błąd jednego kanału nie przerywa źródła', async () => {
  const r = await collectRzeszowiak({
    fixtures: { zatrudnie: fixture('rzeszowiak-a.xml').pathname, agencje: null, dodatkowa: fixture('rzeszowiak-empty.xml').pathname },
  });
  assert.equal(r.ok, true);
  assert.equal(r.items.length, 11);
  assert.match(r.error, /agencje/);
});

test('błąd wszystkich kanałów = źródło z błędem i bez ofert', async () => {
  const r = await collectRzeszowiak({ fixtures: { zatrudnie: null, agencje: null, dodatkowa: null } });
  assert.equal(r.ok, false);
  assert.equal(r.items.length, 0);
});

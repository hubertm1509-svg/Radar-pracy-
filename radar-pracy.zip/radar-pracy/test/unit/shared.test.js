import { test } from 'node:test';
import assert from 'node:assert/strict';
import { normalize, searchText, matchedStems } from '../../src/shared/text.js';
import { detectPlace, distanceFromBase } from '../../src/shared/places.js';
import { DEFAULT_FILTER, evaluate, sanitizeFilter } from '../../src/shared/filter.js';

test('normalize usuwa polskie znaki i interpunkcję', () => {
  assert.equal(normalize('Łańcut – Mechanik/Wózek widłowy!'), 'lancut mechanik wozek widlowy');
  assert.equal(normalize(null), '');
});

test('matchedStems dopasowuje początek słowa', () => {
  assert.deepEqual(matchedStems('Zatrudnię kierowcę C+E', ['kierowc', 'mechanik']), ['kierowc']);
  assert.deepEqual(matchedStems('pakowacz', ['kowa']), []);
});

test('detectPlace: miejscowości z adresu i tytułu', () => {
  assert.equal(detectPlace(['', 'zaklad garmazeryjny jaro w niechobrzu']).name, 'Niechobrz');
  assert.equal(detectPlace(['Hotel w Świlczy']).name, 'Świlcza');
  assert.equal(detectPlace(['praca na produkcji rzeszow32 90']).name, 'Rzeszów');
  assert.equal(detectPlace(['oferty z rzeszowiak pl']), null, 'nazwa portalu to nie miejscowość');
  assert.equal(detectPlace(['ulica Krakowska 5']), null, 'ulica Krakowska to nie Kraków');
  assert.equal(detectPlace(['Pomocnik Operatora Maszyn Zaczernie k/m']).name, 'Zaczernie');
});

test('odległość Niechobrz–Rzeszów ok. 10–11 km w linii prostej', () => {
  const d = distanceFromBase(50.0412, 21.9991);
  assert.ok(d > 9 && d < 12, String(d));
});

test('nieznana lokalizacja nie dostaje odległości', () => {
  assert.equal(detectPlace(['Brukarz', 'zatrudnie brukarza tel']), null);
});

test('evaluate: filtr stanowisk, wykluczeń i odległości', () => {
  const f = sanitizeFilter(DEFAULT_FILTER);
  const mech = { search_text: searchText('Mechanik samochodowy'), distance_km: 5.6 };
  const far = { search_text: searchText('Mechanik samochodowy'), distance_km: 120 };
  const teacher = { search_text: searchText('Nauczyciel przedszkola'), distance_km: 3 };
  const unknown = { search_text: searchText('Kierowca kat. B'), distance_km: null };
  assert.equal(evaluate(mech, f).ok, true);
  assert.deepEqual(evaluate(mech, f).matched, ['mechanik', 'mechani']);
  assert.equal(evaluate(far, f).ok, false);
  assert.equal(evaluate(teacher, f).ok, false);
  assert.equal(evaluate(unknown, f).ok, true);
  assert.equal(evaluate(unknown, { ...f, notifyUnknownDistance: false }, { forNotification: true }).ok, false);
  assert.equal(evaluate(mech, { ...f, exclude: ['samochod'] }).ok, false);
});

test('sanitizeFilter przyjmuje tekst z formularza', () => {
  const f = sanitizeFilter({ include: 'Kierowca\nmagazyn, ', maxKm: '999', exclude: '' });
  assert.deepEqual(f.include, ['kierowca', 'magazyn']);
  assert.equal(f.maxKm, 300);
  assert.deepEqual(f.exclude, []);
});

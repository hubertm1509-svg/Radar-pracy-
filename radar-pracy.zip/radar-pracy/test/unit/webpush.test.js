import { test } from 'node:test';
import assert from 'node:assert/strict';
import { decryptPayload } from '../support/push-decrypt.mjs';
import {
  b64uDecode, b64uEncode, encryptPayload, generateVapidKeys, isAllowedEndpoint, vapidAuthorization,
} from '../../src/worker/webpush.js';

async function ecdhKeyFromRaw(rawPub, d) {
  const pub = b64uDecode(rawPub);
  const jwk = { kty: 'EC', crv: 'P-256', x: b64uEncode(pub.slice(1, 33)), y: b64uEncode(pub.slice(33)), d, ext: true };
  return {
    privateKey: await crypto.subtle.importKey('jwk', jwk, { name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']),
    publicKey: await crypto.subtle.importKey('raw', pub, { name: 'ECDH', namedCurve: 'P-256' }, true, []),
  };
}

test('RFC 8291 dodatek A: zgodność z oficjalnym wektorem testowym', async () => {
  const v = {
    plaintext: 'When I grow up, I want to be a watermelon',
    authSecret: 'BTBZMqHH6r4Tts7J_aSIgg',
    uaPublic: 'BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4',
    uaPrivate: 'q1dXpw3UpT5VOmu_cf_v6ih07Aems3njxI-JWgLcM94',
    asPublic: 'BP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A8',
    asPrivate: 'yfWPiYE-n46HLnH0KqZOF1fJJU3MYrct3AELtAQ-oRw',
    salt: 'DGv6ra1nlYgDCS1FRnbzlw',
    expected: 'DGv6ra1nlYgDCS1FRnbzlwAAEABBBP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A_yl95bQpu6cVPTpK4Mqgkf1CXztLVBSt2Ks3oZwbuwXPXLWyouBWLVWGNWQexSgSxsj_Qulcy4a-fN',
  };
  const asKeyPair = await ecdhKeyFromRaw(v.asPublic, v.asPrivate);
  const body = await encryptPayload(v.plaintext, v.uaPublic, v.authSecret, { asKeyPair, salt: b64uDecode(v.salt) });
  assert.equal(b64uEncode(body), v.expected);
  const ua = await ecdhKeyFromRaw(v.uaPublic, v.uaPrivate);
  assert.equal(await decryptPayload(b64uDecode(v.expected), ua, b64uDecode(v.authSecret)), v.plaintext);
});

test('szyfrowanie i odszyfrowanie z losowymi kluczami', async () => {
  const ua = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const uaPublic = b64uEncode(new Uint8Array(await crypto.subtle.exportKey('raw', ua.publicKey)));
  const auth = crypto.getRandomValues(new Uint8Array(16));
  const msg = JSON.stringify({ notification: { title: 'Mechanik – Boguchwała', body: 'zażółć gęślą jaźń' } });
  const body = await encryptPayload(msg, uaPublic, b64uEncode(auth));
  assert.equal(await decryptPayload(body, ua, auth), msg);
});

test('VAPID: poprawny podpis ES256 i nagłówek "vapid t=…, k=…"', async () => {
  const keys = await generateVapidKeys();
  const header = await vapidAuthorization('https://web.push.apple.com/abc', keys, 'mailto:test@example.com');
  const m = /^vapid t=([^,]+), k=(.+)$/.exec(header);
  assert.ok(m);
  assert.equal(m[2], keys.publicKey);
  const [h, c, s] = m[1].split('.');
  const claims = JSON.parse(new TextDecoder().decode(b64uDecode(c)));
  assert.equal(claims.aud, 'https://web.push.apple.com');
  assert.equal(claims.sub, 'mailto:test@example.com');
  assert.ok(claims.exp > Date.now() / 1000);
  const pub = await crypto.subtle.importKey('raw', b64uDecode(keys.publicKey), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
  const ok = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, pub, b64uDecode(s), new TextEncoder().encode(`${h}.${c}`));
  assert.equal(ok, true);
});

test('dozwolone adresy usług push', () => {
  assert.equal(isAllowedEndpoint('https://web.push.apple.com/QAB', false), true);
  assert.equal(isAllowedEndpoint('https://fcm.googleapis.com/fcm/send/x', false), true);
  assert.equal(isAllowedEndpoint('https://evil.example.com/x', false), false);
  assert.equal(isAllowedEndpoint('http://127.0.0.1:9000/x', false), false);
  assert.equal(isAllowedEndpoint('http://127.0.0.1:9000/x', true), true);
});

# Tworzy pliki testowe w formacie kanału RSS Rzeszowiak.pl (RDF, ISO-8859-2).
# Pozycje 1-8 skopiowane ze struktury prawdziwego kanału z 3.11.2026.
import os
HERE = os.path.dirname(__file__)

def item(slug_id, date, creator=""):
    title = f"{creator} ... " if creator else ""
    cr = f"{creator}&lt;rzeszowiak.pl&gt;" if creator else ""
    url = f"http://www.rzeszowiak.pl/{slug_id}"
    return f"""    <item rdf:about="{url}">
        <dc:format>text/html</dc:format>
        <dc:date>{date}</dc:date>
        <dc:source>http://www.rzeszowiak.pl</dc:source>
        <dc:creator>{cr}</dc:creator>
        <title>{title}</title>
        <link>{url}</link>
        <description></description>
    </item>
"""

BASE = [
    ("alvaros-welding-uslugi-spawalniczo-monterskieoferta-pracyspawacz-migmag-135136miejsce-55311115", "2026-11-02T22:16:01+01:00", "SPAWACZ MIG/MAG (135/136)"),
    ("poszukuje-pomocnika-30-40zl-w-zaleznosci-od-umiejetnosci-i-55311033", "2026-11-02T19:31:27+01:00", "Pomocnik do prac ogolnobudowlanych"),
    ("zaklad-garmazeryjny-jaro-w-niechobrzu-zatrudni-pracownikow-na-55310557", "2026-11-02T11:28:35+01:00", ""),
    ("hotel-w-swilczy-poszukuje-osoby-do-pracy-dodatkowej-55310888", "2026-11-02T16:19:51+01:00", ""),
    ("agencja-pracy-tymczasowej-grh-polska-nr-licencji-16998-55310565", "2026-11-02T11:37:00+01:00", "Pomocnik Operatora Maszyn Zaczernie k/m"),
    ("zatrudnie-brukarza-tel-453316887-55310356", "2026-11-02T09:10:44+01:00", "Brukarz"),
    ("mid-senior-developer-|-szczecinumowa-o-prace-|-55307534", "2026-10-29T11:11:07+01:00", "Programista IT relokacja SZCZECIN ."),
    ("firma-amlux-sp-z-oo-swiadczaca-uslugi-porzadkowe-55308429", "2026-10-30T11:08:03+01:00", ""),
    ("firma-amlux-sp-z-oo-swiadczaca-uslugi-porzadkowe-55306864", "2026-10-28T13:42:18+01:00", ""),
    # Ten sam tytuł i treść pod nowym numerem (ponowne dodanie) – test deduplikacji 2. poziomu
    ("zatrudnie-kierowce-z-kategoria-cetwoj-zakres-obowiazkow-kierowanie-55308739", "2026-10-30T18:20:48+01:00", "Kierowca C+E"),
    ("zatrudnie-kierowce-z-kategoria-cetwoj-zakres-obowiazkow-kierowanie-55309001", "2026-10-31T08:00:00+01:00", "Kierowca C+E"),
]

NEW = [
    ("zatrudnie-mechanika-samochodowego-w-boguchwale-55312001", "2026-11-03T05:00:00+01:00", "Mechanik samochodowy - warsztat Boguchwała"),
    ("przedszkole-w-tyczynie-zatrudni-nauczyciela-55312002", "2026-11-03T05:05:00+01:00", "Nauczyciel wychowania przedszkolnego"),
]

def feed(items):
    head = """<?xml version="1.0" encoding="ISO-8859-2"?>
<!-- generator="FeedCreator 1.7.2" -->
<rdf:RDF
    xmlns="http://purl.org/rss/1.0/"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    xmlns:slash="http://purl.org/rss/1.0/modules/slash/"
    xmlns:dc="http://purl.org/dc/elements/1.1/">
    <channel rdf:about="http://www.rzeszowiak.pl//automat/generuj_rss.php">
        <title>Praca www.rzeszowiak.pl </title>
        <description></description>
        <link>http://www.rzeszowiak.pl/rss/</link>
    </channel>
"""
    return head + "".join(item(*i) for i in items) + "</rdf:RDF>\n"

def write(name, items):
    with open(os.path.join(HERE, name), "wb") as f:
        f.write(feed(items).encode("iso-8859-2"))

write("rzeszowiak-a.xml", BASE)
write("rzeszowiak-b.xml", NEW + BASE)
write("rzeszowiak-empty.xml", [])
print("ok")

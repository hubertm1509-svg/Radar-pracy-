#!/usr/bin/env node
// Synchronizator ofert uruchamiany przez GitHub Actions (albo ręcznie).
// Pobiera źródła, normalizuje oferty i wysyła je do Workera (/api/ingest).
// Nie wypisuje sekretów ani treści prywatnych danych.
//
// Użycie:
//   WORKER_URL=https://... INGEST_SECRET=... node sync/run.js
//   node sync/run.js --dry-run                      (bez wysyłki, tylko podsumowanie)
//   node sync/run.js --fixture zatrudnie=plik.xml   (plik zamiast pobierania; do testów)

import { readFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { decodeXml } from './rss.js';
import * as rzeszowiak from './adapters/rzeszowiak.js';

const USER_AGENT = 'RadarPracy/1.0 (osobisty czytnik RSS; 1 pobranie na 30 min)';

async function fetchFeed(feed, fixtures) {
  if (fixtures && fixtures[feed.key] !== undefined) {
    if (fixtures[feed.key] === null) throw new Error('kanał wyłączony w teście');
    const bytes = await readFile(fixtures[feed.key]);
    return decodeXml(bytes, '');
  }
  const res = await fetch(feed.url, {
    headers: { 'User-Agent': USER_AGENT, Accept: 'application/rss+xml, application/xml, text/xml' },
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const bytes = new Uint8Array(await res.arrayBuffer());
  return decodeXml(bytes, res.headers.get('content-type') || '');
}

export async function collectRzeszowiak({ fixtures } = {}) {
  const now = new Date().toISOString();
  const feeds = [];
  const byId = new Map();
  for (const feed of rzeszowiak.FEEDS) {
    try {
      const xml = await fetchFeed(feed, fixtures);
      const items = rzeszowiak.parseRzeszowiak(xml, feed.key, now);
      for (const it of items) if (!byId.has(it.sourceId)) byId.set(it.sourceId, it);
      feeds.push({ key: feed.key, ok: true, count: items.length, error: null });
    } catch (err) {
      feeds.push({ key: feed.key, ok: false, count: 0, error: String(err.message || err).slice(0, 200) });
    }
  }
  const okFeeds = feeds.filter((f) => f.ok);
  const failed = feeds.filter((f) => !f.ok);
  return {
    source: rzeszowiak.SOURCE,
    ok: okFeeds.length > 0,
    error: failed.length ? failed.map((f) => `${f.key}: ${f.error}`).join('; ') : null,
    feeds,
    items: [...byId.values()],
  };
}

export async function runSync({ workerUrl, secret, fixtures, trigger = 'manual', dryRun = false } = {}) {
  const startedAt = new Date().toISOString();
  const sources = [await collectRzeszowiak({ fixtures })];
  const payload = {
    runId: randomUUID(),
    trigger,
    startedAt,
    finishedAt: new Date().toISOString(),
    sources,
  };
  const summary = sources.map((s) => `${s.source}: ${s.ok ? 'OK' : 'BŁĄD'}, ofert ${s.items.length}${s.error ? ` (${s.error})` : ''}`);
  if (dryRun) return { payload, summary, response: null };

  if (!workerUrl) throw new Error('Brak WORKER_URL (zmienna repozytorium w GitHub → Settings → Secrets and variables → Actions → Variables).');
  if (!secret) throw new Error('Brak INGEST_SECRET (sekret repozytorium w GitHub).');
  const res = await fetch(new URL('/api/ingest', workerUrl), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${secret}`, 'User-Agent': USER_AGENT },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(60000),
  });
  const text = await res.text();
  let body;
  try { body = JSON.parse(text); } catch { body = { raw: text.slice(0, 300) }; }
  if (!res.ok) throw new Error(`Worker odpowiedział HTTP ${res.status}: ${JSON.stringify(body).slice(0, 300)}`);
  return { payload, summary, response: body };
}

function parseArgs(argv) {
  const args = { dryRun: false, fixtures: null };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--dry-run') args.dryRun = true;
    else if (argv[i] === '--fixture') {
      const [key, file] = String(argv[++i] || '').split('=');
      args.fixtures = args.fixtures || {};
      args.fixtures[key] = file === 'FAIL' ? null : file;
    }
  }
  return args;
}

if (import.meta.url === pathToFileURL(process.argv[1] || '').href) {
  const args = parseArgs(process.argv.slice(2));
  if (!args.dryRun && !process.env.WORKER_URL) {
    console.log('WORKER_URL nie jest jeszcze ustawiony – pomijam synchronizację (patrz docs/WDROZENIE.md, krok 4).');
    process.exit(0);
  }
  try {
    const result = await runSync({
      workerUrl: process.env.WORKER_URL,
      secret: process.env.INGEST_SECRET,
      fixtures: args.fixtures,
      trigger: process.env.SYNC_TRIGGER || 'manual',
      dryRun: args.dryRun,
    });
    for (const line of result.summary) console.log(line);
    if (args.dryRun) {
      const items = result.payload.sources[0].items;
      for (const it of items.slice(0, 10)) {
        console.log(`- ${it.title} | ${it.locationText ?? 'lokalizacja do sprawdzenia'}${it.distanceKm !== null ? ` (${it.distanceKm} km)` : ''}`);
      }
    } else {
      const r = result.response;
      console.log(`Nowe oferty: ${r.newJobs ?? 0}, powiadomienia wysłane: ${r.notificationsSent ?? 0}${r.baseline?.length ? `, pierwsza synchronizacja (bez powiadomień): ${r.baseline.join(', ')}` : ''}`);
    }
    if (!result.payload.sources.every((s) => s.ok)) process.exitCode = 2;
  } catch (err) {
    console.error(`Synchronizacja nieudana: ${err.message}`);
    process.exitCode = 1;
  }
}

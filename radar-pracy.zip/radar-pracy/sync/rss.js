// Minimalny czytnik RSS 1.0 (RDF), RSS 2.0 i Atom bez zależności.
// Obsługuje kodowanie z deklaracji XML (np. ISO-8859-2 używane przez Rzeszowiak.pl).

export function decodeXml(bytes, contentType = '') {
  const buf = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const head = new TextDecoder('latin1').decode(buf.slice(0, 200));
  const declared = /encoding=["']([\w-]+)["']/i.exec(head)?.[1];
  const fromHeader = /charset=([\w-]+)/i.exec(contentType)?.[1];
  const encoding = (declared || fromHeader || 'utf-8').toLowerCase();
  try {
    return new TextDecoder(encoding).decode(buf);
  } catch {
    return new TextDecoder('utf-8').decode(buf);
  }
}

const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };

export function decodeEntities(s) {
  return s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&([a-z]+);/gi, (m, n) => ENTITIES[n.toLowerCase()] ?? m);
}

function tag(block, name) {
  const re = new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, 'i');
  const m = re.exec(block);
  return m ? decodeEntities(m[1]).trim() : '';
}

function attr(block, name, attribute) {
  const re = new RegExp(`<${name}\\s[^>]*${attribute}=["']([^"']+)["']`, 'i');
  const m = re.exec(block);
  return m ? decodeEntities(m[1]).trim() : '';
}

export function parseFeed(xml) {
  const items = [];
  const re = /<(item|entry)(?:\s[^>]*)?>([\s\S]*?)<\/\1>/gi;
  let m;
  while ((m = re.exec(xml)) !== null) {
    const block = m[2];
    const about = /rdf:about=["']([^"']+)["']/i.exec(m[0])?.[1] || '';
    items.push({
      title: tag(block, 'title'),
      link: tag(block, 'link') || attr(block, 'link', 'href') || decodeEntities(about),
      guid: tag(block, 'guid') || tag(block, 'id'),
      date: tag(block, 'dc:date') || tag(block, 'pubDate') || tag(block, 'updated') || tag(block, 'published'),
      creator: tag(block, 'dc:creator') || tag(block, 'author'),
      description: tag(block, 'description') || tag(block, 'summary') || tag(block, 'content'),
    });
  }
  return items;
}

export function stripHtml(s) {
  return decodeEntities(String(s || '').replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim();
}

// Adapter Rzeszowiak.pl – oficjalne kanały RSS działu "Praca".
// Kanał podaje: adres ogłoszenia (z numerem na końcu), datę, często tytuł
// (w dc:creator / title, skrócony) i pusty opis. Brakujących danych nie zgadujemy.

import { parseFeed, stripHtml } from '../rss.js';
import { detectPlace } from '../../src/shared/places.js';

export const SOURCE = 'rzeszowiak';

export const FEEDS = [
  { key: 'zatrudnie', url: 'https://www.rzeszowiak.pl/rss/Praca-Zatrudnie.xml', label: 'Zatrudnię' },
  { key: 'agencje', url: 'https://www.rzeszowiak.pl/rss/Praca-Zatrudnie-agencje.xml', label: 'Zatrudnię – agencje' },
  { key: 'dodatkowa', url: 'https://www.rzeszowiak.pl/rss/Praca-Zatrudnie---dodatkowa.xml', label: 'Zatrudnię – dodatkowa' },
];

function canonical(link) {
  try {
    const u = new URL(link.trim());
    u.protocol = 'https:';
    u.hash = '';
    return u.toString();
  } catch {
    return null;
  }
}

function slugOf(url) {
  try {
    const path = decodeURIComponent(new URL(url).pathname).replace(/^\/+|\/+$/g, '');
    return path.replace(/-\d+$/, '');
  } catch {
    return '';
  }
}

export function cleanTitle(raw) {
  return String(raw || '')
    .replace(/<rzeszowiak\.pl>/gi, '')
    .replace(/\s*\.\.\.\s*$/, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function titleFromSlug(slug) {
  const words = slug.replace(/[-_|]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (!words) return null;
  const short = words.length > 90 ? `${words.slice(0, 90).replace(/\s+\S*$/, '')}…` : words;
  return short.charAt(0).toUpperCase() + short.slice(1);
}

// Wynagrodzenie tylko wtedy, gdy w tekście są liczby bezpośrednio przed "zł".
export function extractSalary(text) {
  const t = ` ${String(text || '').toLowerCase().replace(/\s+/g, ' ')} `;
  const m = /(\d{2,5}(?:[ .]\d{3})?)\s*(?:-|–|do|\s)\s*(\d{2,5}(?:[ .]\d{3})?)\s*(?:zl|zł)/.exec(t)
    || /(?:od\s)?(\d{2,5}(?:[ .]\d{3})?)\s*(?:zl|zł)/.exec(t);
  if (!m) return null;
  const toNum = (s) => (s ? Number(s.replace(/[ .]/g, '')) : null);
  let min = toNum(m[1]);
  let max = toNum(m[2]);
  if (max !== null && max < min) [min, max] = [max, min];
  const top = max ?? min;
  if (!min || top < 10) return null;
  const type = top <= 300 ? 'godzinowa' : 'miesięczna';
  return { min, max: max ?? null, type };
}

function extractPhone(text) {
  const m = /(?:tel|telefon|kontakt)\D{0,6}((?:\+?48)?\s?\d{3}[\s-]?\d{3}[\s-]?\d{3})\b/i.exec(text);
  return m ? m[1].replace(/[\s-]/g, '') : null;
}

export function normalizeItems(rawItems, feedKey, nowIso) {
  const out = [];
  for (const it of rawItems) {
    const url = canonical(it.link);
    if (!url || !/rzeszowiak\.pl$/.test(new URL(url).hostname)) continue;
    const id = /-(\d{5,})\/?$/.exec(new URL(url).pathname)?.[1];
    if (!id) continue;
    const slug = slugOf(url);
    const rawTitle = cleanTitle(it.title) || cleanTitle(it.creator);
    const title = rawTitle || titleFromSlug(slug) || 'Ogłoszenie bez tytułu';
    const description = stripHtml(it.description).slice(0, 600) || null;
    const slugText = slug.replace(/[-_|]+/g, ' ');
    const place = detectPlace([rawTitle, slugText, description]);
    const salary = extractSalary(`${rawTitle} ${slugText} ${description || ''}`);
    let publishedAt = null;
    if (it.date) {
      const d = new Date(it.date);
      if (!Number.isNaN(d.getTime())) publishedAt = d.toISOString();
    }
    out.push({
      sourceId: id,
      sourceUrl: url,
      canonicalUrl: url,
      feed: feedKey,
      title,
      titleFromSlug: !rawTitle,
      slugText,
      company: null,
      locationText: place ? place.name : null,
      latitude: place ? place.lat : null,
      longitude: place ? place.lon : null,
      distanceKm: place ? place.distanceKm : null,
      locationApprox: place ? place.approx : false,
      salaryMin: salary ? salary.min : null,
      salaryMax: salary ? salary.max : null,
      salaryType: salary ? salary.type : null,
      contractType: null,
      workMode: null,
      descriptionSummary: description,
      publishedAt,
      contactPhone: extractPhone(`${slugText} ${description || ''}`),
      contactEmail: null,
      requirements: null,
      seenAt: nowIso,
    });
  }
  return out;
}

export function parseRzeszowiak(xml, feedKey, nowIso) {
  return normalizeItems(parseFeed(xml), feedKey, nowIso);
}

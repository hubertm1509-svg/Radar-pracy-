// Normalizacja tekstu wspólna dla synchronizatora (Node) i Workera.
// Wynik: małe litery, bez polskich znaków, tylko [a-z0-9] i pojedyncze spacje.

export function normalize(input) {
  if (input === null || input === undefined) return '';
  return String(input)
    .toLowerCase()
    .replace(/ł/g, 'l')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

// Tekst do wyszukiwania w SQL: spacja na początku i końcu, żeby
// warunek LIKE '% rdzen%' oznaczał "słowo zaczynające się od rdzenia".
export function searchText(...parts) {
  const joined = parts.filter(Boolean).map(normalize).filter(Boolean).join(' ');
  return joined ? ` ${joined} ` : ' ';
}

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Zwraca listę rdzeni (w oryginalnej postaci), które występują w tekście
// jako początek słowa.
export function matchedStems(text, stems) {
  const norm = ` ${normalize(text)} `;
  const out = [];
  for (const stem of stems || []) {
    const s = normalize(stem);
    if (!s) continue;
    if (new RegExp(` ${escapeRegex(s)}`).test(norm)) out.push(stem);
  }
  return out;
}

export function clampString(value, max) {
  if (value === null || value === undefined) return null;
  const s = String(value).trim();
  if (!s) return null;
  return s.length > max ? s.slice(0, max) : s;
}

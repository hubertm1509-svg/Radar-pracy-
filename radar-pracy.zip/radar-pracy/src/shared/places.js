// Lokalny słownik miejscowości (cache geokodowania startowego).
// Współrzędne to środki miejscowości, przybliżone do ok. 1 km.
// Dzielnice Rzeszowa dostają współrzędne środka miasta (błąd do ok. 5 km),
// dlatego mają approx: true i interfejs pokazuje "ok. X km".
// Miejscowości, których nie ma na liście, dostają status "wymaga sprawdzenia"
// i NIE mają wpisanej odległości.

import { normalize } from './text.js';

export const BASE = { name: 'Niechobrz', postalCode: '36-047', lat: 49.98139, lon: 21.86694 };

const RZESZOW = { lat: 50.0412, lon: 21.9991 };

// prefix: słowo zaczyna się od rdzenia; exact: całe słowo; phrase: kilka słów.
export const PLACES = [
  { name: 'Niechobrz', lat: 49.98139, lon: 21.86694, prefix: ['niechobrz'] },
  { name: 'Boguchwała', lat: 49.9846, lon: 21.9447, prefix: ['boguchwal'] },
  { name: 'Rzeszów', ...RZESZOW, prefix: ['rzeszow'], block: ['rzeszowiak'] },
  { name: 'Rzeszów (Zwięczyca)', ...RZESZOW, approx: true, prefix: ['zwieczyc'] },
  { name: 'Rzeszów (Budziwój)', ...RZESZOW, approx: true, prefix: ['budziwoj'] },
  { name: 'Rzeszów (Słocina)', ...RZESZOW, approx: true, prefix: ['slocin'] },
  { name: 'Rzeszów (Przybyszówka)', ...RZESZOW, approx: true, prefix: ['przybyszowk'] },
  { name: 'Rzeszów (Staroniwa)', ...RZESZOW, approx: true, prefix: ['staroniw'] },
  { name: 'Rzeszów (Pobitno)', ...RZESZOW, approx: true, prefix: ['pobitn'] },
  { name: 'Rzeszów (Drabinianka)', ...RZESZOW, approx: true, prefix: ['drabinian'] },
  { name: 'Rzeszów (Miłocin)', ...RZESZOW, approx: true, prefix: ['milocin'] },
  { name: 'Rzeszów (Bzianka)', ...RZESZOW, approx: true, prefix: ['bziank'] },
  { name: 'Rzeszów (Wilkowyja)', ...RZESZOW, approx: true, prefix: ['wilkowyj'] },
  { name: 'Rzeszów (Matysówka)', ...RZESZOW, approx: true, prefix: ['matysowk'] },
  { name: 'Tyczyn', lat: 49.9631, lon: 22.0326, prefix: ['tyczyn'] },
  { name: 'Strzyżów', lat: 49.87, lon: 21.795, prefix: ['strzyzow'] },
  { name: 'Czudec', lat: 49.944, lon: 21.838, exact: ['czudec', 'czudcu', 'czudca'] },
  { name: 'Lubenia', lat: 49.939, lon: 21.937, exact: ['lubenia', 'lubeni'] },
  { name: 'Błażowa', lat: 49.886, lon: 22.104, prefix: ['blazow'] },
  { name: 'Niebylec', lat: 49.857, lon: 21.906, exact: ['niebylec', 'niebylcu', 'niebylca'] },
  { name: 'Frysztak', lat: 49.829, lon: 21.616, exact: ['frysztak', 'frysztaku'] },
  { name: 'Świlcza', lat: 50.056, lon: 21.898, prefix: ['swilcz'] },
  { name: 'Trzebownisko', lat: 50.079, lon: 22.043, prefix: ['trzebownisk'] },
  { name: 'Jasionka', lat: 50.11, lon: 22.019, exact: ['jasionka', 'jasionce', 'jasionki', 'jasionke'] },
  { name: 'Zaczernie', lat: 50.105, lon: 21.985, exact: ['zaczernie', 'zaczerniu', 'zaczernia'] },
  { name: 'Krasne', lat: 50.044, lon: 22.089, exact: ['krasne', 'krasnem'] },
  { name: 'Głogów Małopolski', lat: 50.152, lon: 21.962, exact: ['glogow', 'glogowie', 'glogowa'] },
  { name: 'Sokołów Małopolski', lat: 50.2276, lon: 22.1206, exact: ['sokolow', 'sokolowie', 'sokolowa'] },
  { name: 'Łańcut', lat: 50.0688, lon: 22.2293, prefix: ['lancut'], exact: ['lancucie', 'lancuta'] },
  { name: 'Sędziszów Małopolski', lat: 50.0703, lon: 21.7011, prefix: ['sedziszow'] },
  { name: 'Ropczyce', lat: 50.051, lon: 21.608, prefix: ['ropczyc'] },
  { name: 'Kolbuszowa', lat: 50.244, lon: 21.776, prefix: ['kolbuszow'] },
  { name: 'Dębica', lat: 50.0516, lon: 21.4114, exact: ['debica', 'debicy', 'debice'] },
  { name: 'Pilzno', lat: 49.979, lon: 21.293, exact: ['pilzno', 'pilznie', 'pilzna'] },
  { name: 'Mielec', lat: 50.287, lon: 21.423, exact: ['mielec', 'mielcu', 'mielca'] },
  { name: 'Leżajsk', lat: 50.26, lon: 22.419, prefix: ['lezajsk'] },
  { name: 'Przeworsk', lat: 50.06, lon: 22.493, prefix: ['przeworsk'] },
  { name: 'Jarosław', lat: 50.016, lon: 22.677, exact: ['jaroslawiu'] },
  { name: 'Krosno', lat: 49.689, lon: 21.77, exact: ['krosno', 'krosnie', 'krosna'] },
  { name: 'Jasło', lat: 49.745, lon: 21.471, exact: ['jaslo', 'jasle', 'jasla'] },
  { name: 'Brzozów', lat: 49.695, lon: 22.019, exact: ['brzozow', 'brzozowie'] },
  { name: 'Dynów', lat: 49.815, lon: 22.234, exact: ['dynow', 'dynowie'] },
  { name: 'Sanok', lat: 49.5557, lon: 22.205, exact: ['sanok', 'sanoku'] },
  { name: 'Stalowa Wola', lat: 50.5828, lon: 22.0533, phrase: ['stalowa wol', 'stalowej woli'] },
  { name: 'Tarnów', lat: 50.0121, lon: 20.9858, exact: ['tarnow', 'tarnowie'] },
  { name: 'Kraków', lat: 50.0614, lon: 19.9366, exact: ['krakow', 'krakowie'] },
  { name: 'Lublin', lat: 51.2465, lon: 22.5684, exact: ['lublin', 'lublinie'] },
  { name: 'Warszawa', lat: 52.2297, lon: 21.0122, exact: ['warszawa', 'warszawie'] },
  { name: 'Wrocław', lat: 51.1079, lon: 17.0385, exact: ['wroclaw', 'wroclawiu'] },
  { name: 'Szczecin', lat: 53.4285, lon: 14.5528, prefix: ['szczecin'] },
];

export function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

export function distanceFromBase(lat, lon) {
  return Math.round(haversineKm(BASE.lat, BASE.lon, lat, lon) * 10) / 10;
}

function firstIndex(norm, place) {
  let best = -1;
  const consider = (idx) => {
    if (idx >= 0 && (best === -1 || idx < best)) best = idx;
  };
  const padded = ` ${norm} `;
  for (const p of place.prefix || []) {
    const re = new RegExp(` ${p}[a-z0-9]*`, 'g');
    let m;
    while ((m = re.exec(padded)) !== null) {
      const word = m[0].trim();
      if ((place.block || []).some((b) => word.startsWith(b))) continue;
      consider(m.index);
      break;
    }
  }
  for (const e of place.exact || []) consider(padded.indexOf(` ${e} `));
  for (const ph of place.phrase || []) consider(padded.indexOf(` ${ph}`));
  return best;
}

// Szuka miejscowości w kolejnych tekstach (np. najpierw tytuł, potem adres URL).
// Zwraca pierwszą miejscowość z najwcześniejszego tekstu albo null.
export function detectPlace(texts) {
  for (const t of texts) {
    const norm = normalize(t);
    if (!norm) continue;
    let found = null;
    let foundIdx = -1;
    for (const place of PLACES) {
      const idx = firstIndex(norm, place);
      if (idx >= 0 && (foundIdx === -1 || idx < foundIdx)) {
        found = place;
        foundIdx = idx;
      }
    }
    if (found) {
      return {
        name: found.name,
        lat: found.lat,
        lon: found.lon,
        distanceKm: distanceFromBase(found.lat, found.lon),
        approx: Boolean(found.approx),
      };
    }
  }
  return null;
}

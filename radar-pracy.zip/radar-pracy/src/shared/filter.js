// Filtr domyślny i dopasowanie ofert. Rdzenie są dopasowywane do początku słowa
// po normalizacji (bez polskich znaków), np. "kierowc" łapie "kierowca", "kierowce".

import { normalize, matchedStems } from './text.js';

export const DEFAULT_FILTER = {
  include: [
    'mechanik', 'mechani', 'diagnost', 'warsztat', 'wulkaniz', 'lakiern', 'blachar',
    'magazyn', 'wozek', 'wozkiem', 'widlow', 'udt',
    'produkc', 'budow', 'monter', 'montaz', 'kierowc', 'kurier', 'dostawc',
    'fizyczn', 'przeprowadz', 'utrzymani ruchu', 'serwis', 'operator', 'maszyn',
    'pomocnik', 'slusarz', 'spawacz', 'kostk', 'brukarz',
  ],
  exclude: [],
  maxKm: 30,
  showUnknownDistance: true,
  notifyUnknownDistance: true,
  notify: true,
};

export function sanitizeFilter(input) {
  const f = { ...DEFAULT_FILTER, ...(input || {}) };
  const list = (v) => (Array.isArray(v) ? v : String(v || '').split(/[\n,]/))
    .map((s) => normalize(s))
    .filter((s) => s.length >= 2)
    .slice(0, 60);
  const km = Number(f.maxKm);
  return {
    include: [...new Set(list(f.include))],
    exclude: [...new Set(list(f.exclude))],
    maxKm: Number.isFinite(km) ? Math.min(Math.max(Math.round(km), 1), 300) : 30,
    showUnknownDistance: Boolean(f.showUnknownDistance),
    notifyUnknownDistance: Boolean(f.notifyUnknownDistance),
    notify: Boolean(f.notify),
  };
}

// Zwraca { ok, matched, reasons } – reasons opisuje, z czego wynika wynik.
export function evaluate(job, filter, { forNotification = false } = {}) {
  const text = job.search_text || '';
  const matched = filter.include.length ? matchedStems(text, filter.include) : [];
  const excluded = matchedStems(text, filter.exclude);
  const reasons = [];
  let ok = true;
  if (filter.include.length && matched.length === 0) {
    ok = false;
    reasons.push('brak słów ze stanowisk');
  }
  if (excluded.length) {
    ok = false;
    reasons.push(`słowa wykluczone: ${excluded.join(', ')}`);
  }
  if (job.distance_km === null || job.distance_km === undefined) {
    const allow = forNotification ? filter.notifyUnknownDistance : filter.showUnknownDistance;
    if (!allow) {
      ok = false;
      reasons.push('nieznana odległość');
    }
  } else if (job.distance_km > filter.maxKm) {
    ok = false;
    reasons.push(`odległość ${job.distance_km} km > ${filter.maxKm} km`);
  }
  return { ok, matched, excluded, reasons };
}

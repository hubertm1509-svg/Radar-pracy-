// Prywatne API aplikacji (wymaga zalogowania).

import { normalize } from '../shared/text.js';
import { evaluate, sanitizeFilter } from '../shared/filter.js';
import { HttpError, getDefaultFilter, getSetting, getVapid, json, nowIso, readJson } from './util.js';
import { isAllowedEndpoint } from './webpush.js';
import { sendTest } from './notify.js';

export const STATUSES = ['nowa', 'przeczytana', 'aplikowalem', 'rozmowa', 'odrzucona', 'zatrudniony', 'pominieta'];

const LIST_COLUMNS = `id, source, title, title_from_slug, company, location_text, distance_km, location_approx,
  location_status, salary_min, salary_max, salary_type, published_at, first_seen_at, canonical_url,
  is_read, is_saved, status, search_text`;

function publicJob(row, filter) {
  const { search_text: searchTextValue, ...rest } = row;
  const ev = filter ? evaluate({ search_text: searchTextValue, distance_km: row.distance_km }, filter) : null;
  return {
    ...rest,
    is_new: row.status === 'nowa',
    match: ev ? { ok: ev.ok, matched: ev.matched, reasons: ev.reasons } : null,
  };
}

export async function listJobs(url, env) {
  const db = env.DB;
  const filter = await getDefaultFilter(db);
  const view = url.searchParams.get('widok') || 'pasujace';
  const q = normalize(url.searchParams.get('q') || '');
  const limit = Math.min(Math.max(Number(url.searchParams.get('limit')) || 50, 1), 100);
  const offset = Math.min(Math.max(Number(url.searchParams.get('offset')) || 0, 0), 5000);
  const maxKmParam = url.searchParams.get('maxKm');

  const where = ['duplicate_of IS NULL'];
  const params = [];
  const p = (v) => {
    params.push(v);
    return `?${params.length}`;
  };

  if (view === 'pasujace') {
    if (filter.include.length) where.push(`(${filter.include.map((s) => `search_text LIKE ${p(`% ${s}%`)}`).join(' OR ')})`);
    for (const s of filter.exclude) where.push(`search_text NOT LIKE ${p(`% ${s}%`)}`);
    where.push(filter.showUnknownDistance
      ? `(distance_km IS NULL OR distance_km <= ${p(filter.maxKm)})`
      : `distance_km <= ${p(filter.maxKm)}`);
  } else if (view === 'nowe') {
    where.push("status = 'nowa'");
  } else if (view === 'zapisane') {
    where.push('is_saved = 1');
  } else if (view !== 'wszystkie') {
    throw new HttpError(400, 'Nieznany widok');
  }
  if (maxKmParam !== null && maxKmParam !== '' && view !== 'pasujace') {
    const km = Number(maxKmParam);
    if (Number.isFinite(km)) where.push(`(distance_km IS NULL OR distance_km <= ${p(km)})`);
  }
  if (q) where.push(`search_text LIKE ${p(`%${q}%`)}`);

  const sql = `SELECT ${LIST_COLUMNS} FROM jobs WHERE ${where.join(' AND ')}
    ORDER BY COALESCE(published_at, first_seen_at) DESC, id DESC LIMIT ${p(limit + 1)} OFFSET ${p(offset)}`;
  const { results } = await db.prepare(sql).bind(...params).all();
  const hasMore = results.length > limit;
  return json({
    view,
    filter: { maxKm: filter.maxKm },
    jobs: results.slice(0, limit).map((r) => publicJob(r, filter)),
    hasMore,
    nextOffset: hasMore ? offset + limit : null,
  });
}

export async function getJob(id, env) {
  const db = env.DB;
  const job = await db.prepare('SELECT * FROM jobs WHERE id = ?1').bind(id).first();
  if (!job) throw new HttpError(404, 'Nie ma takiej oferty');
  const filter = await getDefaultFilter(db);
  const [note, history, urls, similar] = await db.batch([
    db.prepare('SELECT note, updated_at FROM notes WHERE job_id = ?1').bind(id),
    db.prepare('SELECT status, changed_at FROM application_status WHERE job_id = ?1 ORDER BY id DESC LIMIT 20').bind(id),
    db.prepare('SELECT source, source_url, first_seen_at FROM job_sources WHERE job_id = ?1').bind(id),
    db.prepare(
      'SELECT id, source_url, first_seen_at FROM jobs WHERE raw_fingerprint = ?1 AND id != ?2 AND title_from_slug = 0 ORDER BY id LIMIT 10',
    ).bind(job.raw_fingerprint, id),
  ]);
  const { raw_fingerprint: _fp, ...rest } = job;
  return json({
    ...publicJob(rest, filter),
    note: note.results[0]?.note ?? '',
    note_updated_at: note.results[0]?.updated_at ?? null,
    history: history.results,
    source_urls: urls.results,
    duplicates: similar.results,
  });
}

export async function patchJob(id, request, env) {
  const db = env.DB;
  const body = await readJson(request, 20_000);
  const job = await db.prepare('SELECT id, status FROM jobs WHERE id = ?1').bind(id).first();
  if (!job) throw new HttpError(404, 'Nie ma takiej oferty');
  const now = nowIso();
  const stmts = [];
  if (body.read === true) {
    stmts.push(db.prepare("UPDATE jobs SET is_read = 1, status = CASE WHEN status = 'nowa' THEN 'przeczytana' ELSE status END WHERE id = ?1").bind(id));
  }
  if (typeof body.saved === 'boolean') {
    stmts.push(db.prepare('UPDATE jobs SET is_saved = ?1 WHERE id = ?2').bind(body.saved ? 1 : 0, id));
  }
  if (body.status !== undefined) {
    if (!STATUSES.includes(body.status)) throw new HttpError(400, 'Nieznany status');
    if (body.status !== job.status) {
      stmts.push(db.prepare('UPDATE jobs SET status = ?1, is_read = 1 WHERE id = ?2').bind(body.status, id));
      stmts.push(db.prepare('INSERT INTO application_status (job_id, status, changed_at) VALUES (?1, ?2, ?3)').bind(id, body.status, now));
    }
  }
  if (typeof body.note === 'string') {
    const note = body.note.slice(0, 5000);
    stmts.push(note.trim()
      ? db.prepare('INSERT INTO notes (job_id, note, updated_at) VALUES (?1, ?2, ?3) ON CONFLICT(job_id) DO UPDATE SET note = excluded.note, updated_at = excluded.updated_at').bind(id, note, now)
      : db.prepare('DELETE FROM notes WHERE job_id = ?1').bind(id));
  }
  if (stmts.length) await db.batch(stmts);
  return getJob(id, env);
}

export async function getFilter(env) {
  return json(await getDefaultFilter(env.DB));
}

export async function putFilter(request, env) {
  const db = env.DB;
  const current = await getDefaultFilter(db);
  const body = await readJson(request, 20_000);
  const next = sanitizeFilter({ ...current, ...body });
  await db.prepare('UPDATE filters SET config = ?1, updated_at = ?2 WHERE id = ?3').bind(JSON.stringify(next), nowIso(), current.id).run();
  return json({ id: current.id, ...next });
}

const DELAY_MINUTES = 90;

export function sourceUiStatus(s, now = Date.now()) {
  if (s.integration === 'manual_source') return 'reczne';
  if (s.integration === 'official_alert') return 'reczne';
  if (s.integration === 'unsupported') return 'nieobslugiwane';
  if (s.integration === 'requires_configuration') return 'wymaga_konfiguracji';
  if (s.consecutive_errors > 0) return 'blad';
  if (!s.last_success_at) return 'opoznione';
  return now - Date.parse(s.last_success_at) > DELAY_MINUTES * 60000 ? 'opoznione' : 'dziala';
}

export async function getSources(env) {
  const db = env.DB;
  const [sources, runs, counts] = await db.batch([
    db.prepare('SELECT * FROM source_state ORDER BY CASE integration WHEN \'active\' THEN 0 WHEN \'official_alert\' THEN 1 WHEN \'requires_configuration\' THEN 2 ELSE 3 END, name'),
    db.prepare('SELECT run_id, trigger, started_at, finished_at, status, sources_ok, sources_failed, items_received, items_new, notifications_sent, error FROM sync_runs ORDER BY id DESC LIMIT 20'),
    db.prepare('SELECT source, COUNT(*) AS n FROM jobs GROUP BY source'),
  ]);
  const total = Object.fromEntries(counts.results.map((r) => [r.source, r.n]));
  return json({
    sources: sources.results.map((s) => ({ ...s, ui_status: sourceUiStatus(s), total_jobs: total[s.source] || 0 })),
    runs: runs.results,
  });
}

export async function getDiag(env) {
  const db = env.DB;
  const [subs, lastRun, settings] = await db.batch([
    db.prepare('SELECT COUNT(*) AS active, MAX(last_seen_at) AS last_seen FROM push_subscriptions WHERE active = 1'),
    db.prepare('SELECT finished_at, status FROM sync_runs ORDER BY id DESC LIMIT 1'),
    db.prepare("SELECT key, value FROM settings WHERE key IN ('last_test_push_at', 'last_job_push_at')"),
  ]);
  const s = Object.fromEntries(settings.results.map((r) => [r.key, r.value]));
  return json({
    activeSubscriptions: subs.results[0].active,
    lastSubscriptionSeen: subs.results[0].last_seen,
    lastTestPushAt: s.last_test_push_at || null,
    lastJobPushAt: s.last_job_push_at || null,
    lastSync: lastRun.results[0] || null,
    ingestConfigured: Boolean(env.INGEST_SECRET && String(env.INGEST_SECRET).length >= 24),
  });
}

export async function getPushKey(env) {
  const vapid = await getVapid(env);
  return json({ publicKey: vapid.publicKey });
}

export async function subscribe(request, env) {
  const body = await readJson(request, 10_000);
  const endpoint = String(body.endpoint || '');
  const p256dh = String(body.keys?.p256dh || '');
  const auth = String(body.keys?.auth || '');
  if (!isAllowedEndpoint(endpoint, env.ALLOW_TEST_PUSH_ENDPOINT === '1')) throw new HttpError(400, 'Niedozwolony adres usługi push');
  if (!/^[A-Za-z0-9_-]{80,100}$/.test(p256dh) || !/^[A-Za-z0-9_-]{20,24}$/.test(auth)) throw new HttpError(400, 'Nieprawidłowe klucze subskrypcji');
  const now = nowIso();
  const ua = String(request.headers.get('user-agent') || '').slice(0, 200);
  await env.DB.prepare(
    `INSERT INTO push_subscriptions (endpoint, p256dh, auth, user_agent, created_at, last_seen_at, active)
     VALUES (?1, ?2, ?3, ?4, ?5, ?5, 1)
     ON CONFLICT(endpoint) DO UPDATE SET p256dh = excluded.p256dh, auth = excluded.auth,
       user_agent = excluded.user_agent, last_seen_at = excluded.last_seen_at, active = 1, failures = 0, last_error = NULL`,
  ).bind(endpoint, p256dh, auth, ua, now).run();
  return json({ ok: true });
}

export async function unsubscribe(request, env) {
  const body = await readJson(request, 10_000);
  await env.DB.prepare('UPDATE push_subscriptions SET active = 0 WHERE endpoint = ?1').bind(String(body.endpoint || '')).run();
  return json({ ok: true });
}

export async function pushTest(request, env) {
  const body = await readJson(request, 2_000);
  const origin = new URL(request.url).origin;
  let job = null;
  if (body.withJob) {
    job = await env.DB.prepare(
      'SELECT * FROM jobs WHERE duplicate_of IS NULL ORDER BY COALESCE(published_at, first_seen_at) DESC, id DESC LIMIT 1',
    ).first();
    if (!job) throw new HttpError(409, 'Brak ofert w bazie – najpierw uruchom synchronizację.');
  }
  const results = await sendTest(env, origin, job);
  if (!results.length) throw new HttpError(409, 'Brak aktywnej subskrypcji. Najpierw włącz powiadomienia na tym urządzeniu.');
  return json({ results, lastTestPushAt: await getSetting(env.DB, 'last_test_push_at') });
}

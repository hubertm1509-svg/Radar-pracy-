import { DEFAULT_FILTER, sanitizeFilter } from '../shared/filter.js';
import { generateVapidKeys } from './webpush.js';

export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      ...headers,
    },
  });
}

export async function readJson(request, maxBytes = 1_500_000) {
  const len = Number(request.headers.get('content-length') || 0);
  if (len > maxBytes) throw new HttpError(413, 'Za duże żądanie');
  const text = await request.text();
  if (text.length > maxBytes) throw new HttpError(413, 'Za duże żądanie');
  try {
    return text ? JSON.parse(text) : {};
  } catch {
    throw new HttpError(400, 'Nieprawidłowy JSON');
  }
}

export const nowIso = () => new Date().toISOString();

export async function getSetting(db, key) {
  const row = await db.prepare('SELECT value FROM settings WHERE key = ?').bind(key).first();
  return row ? row.value : null;
}

export async function setSetting(db, key, value) {
  await db.prepare(
    'INSERT INTO settings (key, value, updated_at) VALUES (?1, ?2, ?3) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at',
  ).bind(key, String(value), nowIso()).run();
}

// Wartość tworzona raz i trzymana w D1 (np. sekret sesji, klucze VAPID).
export async function getOrCreateSetting(db, key, create) {
  const existing = await getSetting(db, key);
  if (existing) return existing;
  const value = await create();
  await db.prepare('INSERT OR IGNORE INTO settings (key, value, updated_at) VALUES (?1, ?2, ?3)').bind(key, value, nowIso()).run();
  return (await getSetting(db, key)) || value;
}

export async function getVapid(env) {
  if (env.VAPID_PUBLIC_KEY && env.VAPID_PRIVATE_KEY) {
    return { publicKey: env.VAPID_PUBLIC_KEY, privateKey: env.VAPID_PRIVATE_KEY };
  }
  const raw = await getOrCreateSetting(env.DB, 'vapid_keys', async () => JSON.stringify(await generateVapidKeys()));
  return JSON.parse(raw);
}

export async function getDefaultFilter(db) {
  let row = await db.prepare('SELECT id, config FROM filters WHERE is_default = 1 ORDER BY id LIMIT 1').first();
  if (!row) {
    await db.prepare('INSERT INTO filters (name, config, is_default, updated_at) VALUES (?1, ?2, 1, ?3)')
      .bind('Domyślny', JSON.stringify(sanitizeFilter(DEFAULT_FILTER)), nowIso()).run();
    row = await db.prepare('SELECT id, config FROM filters WHERE is_default = 1 ORDER BY id LIMIT 1').first();
  }
  let config;
  try { config = JSON.parse(row.config); } catch { config = DEFAULT_FILTER; }
  return { id: row.id, ...sanitizeFilter(config) };
}

export function timingSafeEqualBytes(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

export async function sha256(text) {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)));
}

export async function sha256Hex(text) {
  return [...(await sha256(text))].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function secretsEqual(a, b) {
  return timingSafeEqualBytes(await sha256(String(a ?? '')), await sha256(String(b ?? '')));
}

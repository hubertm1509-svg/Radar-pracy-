// Wysyłka powiadomień o ofertach. Zasady:
// - jedna oferta = najwyżej jedno powiadomienie na subskrypcję i filtr (unikalny indeks),
// - status "sent" dopiero po odpowiedzi 2xx usługi push,
// - wygasłe subskrypcje (404/410) są dezaktywowane,
// - przy wielu nowych ofertach naraz: kilka pojedynczych + jedno zbiorcze.

import { sendWebPush } from './webpush.js';
import { getVapid, nowIso, setSetting } from './util.js';

const MAX_SINGLE = 4;

function formatSalary(job) {
  if (job.salary_min === null || job.salary_min === undefined) return null;
  const unit = job.salary_type === 'godzinowa' ? 'zł/h' : 'zł';
  return job.salary_max ? `${job.salary_min}–${job.salary_max} ${unit}` : `${job.salary_min} ${unit}`;
}

export function jobMessage(job, origin) {
  const parts = [];
  if (job.company) parts.push(job.company);
  if (job.location_text) {
    parts.push(job.distance_km !== null && job.distance_km !== undefined
      ? `${job.location_text} (${job.location_approx ? 'ok. ' : ''}${job.distance_km} km)`
      : job.location_text);
  } else {
    parts.push('lokalizacja do sprawdzenia');
  }
  const salary = formatSalary(job);
  if (salary) parts.push(salary);
  const title = job.title.length > 90 ? `${job.title.slice(0, 89)}…` : job.title;
  return {
    web_push: 8030,
    notification: {
      title,
      body: parts.join(' · '),
      navigate: `${origin}/#/oferta/${job.id}`,
      tag: `job-${job.id}`,
    },
  };
}

function summaryMessage(count, origin) {
  return {
    web_push: 8030,
    notification: {
      title: `Jeszcze ${count} nowych ofert`,
      body: 'Otwórz Radar Pracy, żeby je przejrzeć.',
      navigate: `${origin}/#/?widok=nowe`,
      tag: 'summary',
    },
  };
}

function subject(env, origin) {
  return env.VAPID_SUBJECT || origin;
}

async function deliver(env, sub, message, notificationId, origin) {
  const vapid = await getVapid(env);
  const result = await sendWebPush(sub, message, vapid, subject(env, origin));
  const db = env.DB;
  const now = nowIso();
  if (result.ok) {
    await db.batch([
      db.prepare("UPDATE notifications SET status = 'sent', attempts = attempts + 1, http_status = ?1, sent_at = ?2 WHERE id = ?3").bind(result.status, now, notificationId),
      db.prepare('UPDATE push_subscriptions SET failures = 0, last_error = NULL WHERE id = ?1').bind(sub.id),
    ]);
  } else if (result.gone) {
    await db.batch([
      db.prepare("UPDATE notifications SET status = 'expired', attempts = attempts + 1, http_status = ?1 WHERE id = ?2").bind(result.status, notificationId),
      db.prepare('UPDATE push_subscriptions SET active = 0, last_error = ?1 WHERE id = ?2').bind(`HTTP ${result.status} – subskrypcja wygasła`, sub.id),
    ]);
  } else {
    await db.batch([
      db.prepare("UPDATE notifications SET status = 'failed', attempts = attempts + 1, http_status = ?1 WHERE id = ?2").bind(result.status, notificationId),
      db.prepare('UPDATE push_subscriptions SET failures = failures + 1, last_error = ?1 WHERE id = ?2').bind(`HTTP ${result.status}${result.error ? `: ${result.error}` : ''}`.slice(0, 300), sub.id),
    ]);
  }
  return result;
}

async function activeSubscriptions(db) {
  const { results } = await db.prepare('SELECT id, endpoint, p256dh, auth FROM push_subscriptions WHERE active = 1').all();
  return results;
}

// Zakłada wpis "pending" tylko raz; zwraca id albo null, jeśli już istniał.
async function claim(db, jobId, subId, filterId, kind) {
  const row = await db.prepare(
    `INSERT INTO notifications (job_id, subscription_id, filter_id, kind, status, attempts, created_at)
     VALUES (?1, ?2, ?3, ?4, ?5, 0, ?6)
     ON CONFLICT (job_id, subscription_id, filter_id) WHERE job_id IS NOT NULL DO NOTHING
     RETURNING id`,
  ).bind(jobId, subId, filterId, kind, kind === 'summarized' ? 'summarized' : 'pending', nowIso()).first();
  return row ? row.id : null;
}

export async function notifyJobs(env, jobs, filterId, origin) {
  const db = env.DB;
  const stats = { sent: 0, failed: 0, skipped: 0 };
  if (!jobs.length) return stats;
  const subs = await activeSubscriptions(db);
  if (!subs.length) return stats;

  const ordered = [...jobs].sort((a, b) => (a.distance_km ?? 999) - (b.distance_km ?? 999));
  const single = ordered.length > MAX_SINGLE + 1 ? ordered.slice(0, MAX_SINGLE) : ordered;
  const rest = ordered.slice(single.length);

  for (const sub of subs) {
    for (const job of single) {
      const id = await claim(db, job.id, sub.id, filterId, 'job');
      if (!id) { stats.skipped++; continue; }
      const r = await deliver(env, sub, jobMessage(job, origin), id, origin);
      if (r.ok) stats.sent++; else stats.failed++;
      if (r.gone) break;
    }
    if (rest.length) {
      let claimed = 0;
      for (const job of rest) if (await claim(db, job.id, sub.id, filterId, 'summarized')) claimed++;
      if (claimed) {
        const row = await db.prepare(
          "INSERT INTO notifications (job_id, subscription_id, filter_id, kind, status, attempts, created_at) VALUES (NULL, ?1, ?2, 'summary', 'pending', 0, ?3) RETURNING id",
        ).bind(sub.id, filterId, nowIso()).first();
        const r = await deliver(env, sub, summaryMessage(claimed, origin), row.id, origin);
        if (r.ok) stats.sent++; else stats.failed++;
      }
    }
  }
  if (stats.sent) await setSetting(db, 'last_job_push_at', nowIso());
  return stats;
}

// Ponowienie nieudanych (nie wygasłych) powiadomień o ofertach: max 3 próby, do 6 h.
export async function retryFailed(env, origin) {
  const db = env.DB;
  const since = new Date(Date.now() - 6 * 3600_000).toISOString();
  const { results } = await db.prepare(
    `SELECT n.id AS nid, n.subscription_id AS sid, s.endpoint, s.p256dh, s.auth,
            j.id, j.title, j.company, j.location_text, j.distance_km, j.location_approx,
            j.salary_min, j.salary_max, j.salary_type
       FROM notifications n
       JOIN push_subscriptions s ON s.id = n.subscription_id AND s.active = 1
       JOIN jobs j ON j.id = n.job_id
      WHERE n.status = 'failed' AND n.kind = 'job' AND n.attempts < 3 AND n.created_at >= ?1
      LIMIT 5`,
  ).bind(since).all();
  let sent = 0;
  for (const row of results) {
    const sub = { id: row.sid, endpoint: row.endpoint, p256dh: row.p256dh, auth: row.auth };
    const r = await deliver(env, sub, jobMessage(row, origin), row.nid, origin);
    if (r.ok) sent++;
  }
  return sent;
}

export async function sendTest(env, origin, job) {
  const db = env.DB;
  const subs = await activeSubscriptions(db);
  const results = [];
  const message = job
    ? jobMessage(job, origin)
    : {
      web_push: 8030,
      notification: {
        title: 'Radar Pracy – test',
        body: 'Powiadomienia działają. Kliknij, żeby otworzyć aplikację.',
        navigate: `${origin}/#/ustawienia`,
        tag: 'test',
      },
    };
  if (job) message.notification.title = `[TEST] ${message.notification.title}`;
  for (const sub of subs) {
    const row = await db.prepare(
      "INSERT INTO notifications (job_id, subscription_id, filter_id, kind, status, attempts, created_at) VALUES (NULL, ?1, NULL, 'test', 'pending', 0, ?2) RETURNING id",
    ).bind(sub.id, nowIso()).first();
    const r = await deliver(env, sub, message, row.id, origin);
    results.push({ subscriptionId: sub.id, ok: r.ok, status: r.status, expired: r.gone });
  }
  if (results.some((r) => r.ok)) await setSetting(db, 'last_test_push_at', nowIso());
  return results;
}

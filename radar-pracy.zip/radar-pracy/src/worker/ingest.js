// Przyjmowanie ofert od synchronizatora (GitHub Actions).
// Idempotentne: ten sam runId nie jest przetwarzany dwa razy, a ta sama oferta
// (źródło + id, albo ten sam adres) nie tworzy nowego wiersza.

import { clampString, normalize, searchText } from '../shared/text.js';
import { evaluate } from '../shared/filter.js';
import { HttpError, getDefaultFilter, json, nowIso, readJson, sha256Hex } from './util.js';
import { notifyJobs, retryFailed } from './notify.js';

const MAX_ITEMS = 1000;

const num = (v, min, max) => {
  const n = Number(v);
  return v === null || v === undefined || v === '' || !Number.isFinite(n) || n < min || n > max ? null : n;
};

async function sanitizeItem(raw) {
  const sourceId = clampString(raw.sourceId, 100);
  const sourceUrl = clampString(raw.sourceUrl, 600);
  const canonicalUrl = clampString(raw.canonicalUrl || raw.sourceUrl, 600);
  const title = clampString(raw.title, 300);
  if (!sourceId || !sourceUrl || !canonicalUrl || !title) return null;
  if (!/^https?:\/\//.test(sourceUrl) || !/^https?:\/\//.test(canonicalUrl)) return null;
  let publishedAt = null;
  if (raw.publishedAt) {
    const d = new Date(raw.publishedAt);
    if (!Number.isNaN(d.getTime())) publishedAt = d.toISOString();
  }
  const company = clampString(raw.company, 200);
  const locationText = clampString(raw.locationText, 120);
  const latitude = num(raw.latitude, -90, 90);
  const longitude = num(raw.longitude, -180, 180);
  const distanceKm = latitude !== null && longitude !== null ? num(raw.distanceKm, 0, 20000) : null;
  const description = clampString(raw.descriptionSummary, 600);
  const slugText = clampString(raw.slugText, 600);
  const titleFromSlug = raw.titleFromSlug ? 1 : 0;
  // Odcisk do deduplikacji drugiego poziomu (ten sam tytuł, firma, miejsce i treść).
  const fingerprint = await sha256Hex([title, company, locationText, slugText || description].map(normalize).join('|'));
  return {
    sourceId,
    sourceUrl,
    canonicalUrl,
    title,
    titleFromSlug,
    company,
    locationText,
    latitude,
    longitude,
    distanceKm,
    locationApprox: raw.locationApprox ? 1 : 0,
    locationStatus: distanceKm !== null ? 'ok' : 'wymaga_sprawdzenia',
    salaryMin: num(raw.salaryMin, 1, 1_000_000),
    salaryMax: num(raw.salaryMax, 1, 1_000_000),
    salaryType: clampString(raw.salaryType, 30),
    contractType: clampString(raw.contractType, 60),
    workMode: clampString(raw.workMode, 30),
    descriptionSummary: description,
    publishedAt,
    contactPhone: clampString(raw.contactPhone, 30),
    contactEmail: clampString(raw.contactEmail, 120),
    requirements: clampString(raw.requirements, 600),
    fingerprint,
    searchText: searchText(title, slugText, company, locationText, description),
  };
}

const COLS = [
  ['source_id', 'sourceId'], ['source_url', 'sourceUrl'], ['canonical_url', 'canonicalUrl'], ['title', 'title'],
  ['title_from_slug', 'titleFromSlug'], ['company', 'company'], ['location_text', 'locationText'],
  ['latitude', 'latitude'], ['longitude', 'longitude'], ['distance_km', 'distanceKm'],
  ['location_approx', 'locationApprox'], ['location_status', 'locationStatus'],
  ['salary_min', 'salaryMin'], ['salary_max', 'salaryMax'], ['salary_type', 'salaryType'],
  ['contract_type', 'contractType'], ['work_mode', 'workMode'], ['description_summary', 'descriptionSummary'],
  ['published_at', 'publishedAt'], ['contact_phone', 'contactPhone'], ['contact_email', 'contactEmail'],
  ['requirements', 'requirements'], ['raw_fingerprint', 'fingerprint'], ['search_text', 'searchText'],
];

const INSERT_SQL = `INSERT OR IGNORE INTO jobs (source, first_seen_at, last_seen_at, baseline, ${COLS.map((c) => c[0]).join(', ')})
SELECT ?1, ?2, ?2, ?3, ${COLS.map((c) => `json_extract(value, '$.${c[1]}')`).join(', ')}
FROM json_each(?4) WHERE true`;

async function processSource(env, src, now, runStats) {
  const db = env.DB;
  const state = await db.prepare('SELECT * FROM source_state WHERE source = ?1').bind(String(src.source || '')).first();
  if (!state) return { source: src.source, error: 'nieznane źródło' };
  if (state.integration !== 'active') return { source: src.source, error: 'źródło nieaktywne' };

  if (!src.ok) {
    await db.prepare(
      'UPDATE source_state SET last_attempt_at = ?1, last_error = ?2, consecutive_errors = consecutive_errors + 1 WHERE source = ?3',
    ).bind(now, clampString(src.error || 'nieznany błąd', 500), state.source).run();
    runStats.failed++;
    return { source: state.source, ok: false, newJobs: [] };
  }

  const rawItems = Array.isArray(src.items) ? src.items.slice(0, MAX_ITEMS) : [];
  const items = (await Promise.all(rawItems.map(sanitizeItem))).filter(Boolean);
  const isBaseline = !state.baseline_done;
  runStats.received += items.length;
  const payload = JSON.stringify(items);

  // Kolejne kroki w jednej transakcji (batch D1).
  await db.batch([
    db.prepare(INSERT_SQL).bind(state.source, now, isBaseline ? 1 : 0, payload),
    db.prepare(
      // last_seen_at odświeżane najwyżej co 6 h – oszczędza dzienny limit zapisów D1.
      "UPDATE jobs SET last_seen_at = ?1 WHERE source = ?2 AND last_seen_at < ?4 AND source_id IN (SELECT json_extract(value, '$.sourceId') FROM json_each(?3))",
    ).bind(now, state.source, payload, new Date(Date.now() - 6 * 3600_000).toISOString()),
    db.prepare(
      'INSERT OR IGNORE INTO job_sources (job_id, source, source_url, first_seen_at) SELECT id, source, source_url, first_seen_at FROM jobs WHERE source = ?1 AND first_seen_at = ?2',
    ).bind(state.source, now),
    // Deduplikacja 2. poziomu: tylko oferty z prawdziwym tytułem (różne stanowiska
    // tej samej firmy mają różne tytuły i nie zostaną połączone).
    db.prepare(
      `UPDATE jobs SET duplicate_of = (
          SELECT MIN(o.id) FROM jobs o
           WHERE o.raw_fingerprint = jobs.raw_fingerprint AND o.id < jobs.id AND o.title_from_slug = 0
             AND o.first_seen_at >= ?3)
        WHERE source = ?1 AND first_seen_at = ?2 AND title_from_slug = 0`,
    ).bind(state.source, now, new Date(Date.now() - 45 * 86400_000).toISOString()),
    db.prepare(
      `UPDATE source_state SET last_attempt_at = ?1, last_success_at = ?1, last_error = ?2, last_count = ?3,
              consecutive_errors = 0, baseline_done = 1 WHERE source = ?4`,
    ).bind(now, src.error ? clampString(`Częściowo: ${src.error}`, 500) : null, items.length, state.source),
  ]);

  const { results } = await db.prepare(
    'SELECT * FROM jobs WHERE source = ?1 AND first_seen_at = ?2 AND duplicate_of IS NULL',
  ).bind(state.source, now).all();
  runStats.ok++;
  runStats.newCount += results.length;
  return { source: state.source, ok: true, baseline: isBaseline, newJobs: isBaseline ? [] : results };
}

export async function handleIngest(request, env) {
  const body = await readJson(request);
  const runId = clampString(body.runId, 80);
  if (!runId || !Array.isArray(body.sources)) throw new HttpError(400, 'Brak runId lub sources');
  const db = env.DB;
  const now = nowIso();

  const inserted = await db.prepare(
    "INSERT INTO sync_runs (run_id, trigger, started_at, status) VALUES (?1, ?2, ?3, 'running') ON CONFLICT(run_id) DO NOTHING RETURNING id",
  ).bind(runId, clampString(body.trigger, 30), clampString(body.startedAt, 40) || now).first();
  if (!inserted) return json({ ok: true, duplicateRun: true, newJobs: 0, notificationsSent: 0 });

  const runStats = { ok: 0, failed: 0, received: 0, newCount: 0 };
  const origin = new URL(request.url).origin;
  const baseline = [];
  const candidates = [];
  let error = null;
  let pushStats = { sent: 0, failed: 0, skipped: 0 };
  try {
    for (const src of body.sources.slice(0, 20)) {
      const r = await processSource(env, src, now, runStats);
      if (r.baseline) baseline.push(r.source);
      if (r.newJobs) candidates.push(...r.newJobs);
    }
    const filter = await getDefaultFilter(db);
    const matching = filter.notify ? candidates.filter((j) => evaluate(j, filter, { forNotification: true }).ok) : [];
    pushStats = await notifyJobs(env, matching, filter.id, origin);
    pushStats.sent += await retryFailed(env, origin);
  } catch (err) {
    error = String(err.message || err).slice(0, 500);
  }

  const status = error ? 'error' : runStats.failed ? (runStats.ok ? 'partial' : 'error') : 'ok';
  await db.prepare(
    `UPDATE sync_runs SET finished_at = ?1, status = ?2, sources_ok = ?3, sources_failed = ?4,
            items_received = ?5, items_new = ?6, notifications_sent = ?7, error = ?8 WHERE id = ?9`,
  ).bind(nowIso(), status, runStats.ok, runStats.failed, runStats.received, runStats.newCount, pushStats.sent, error, inserted.id).run();

  if (error) throw new HttpError(500, `Błąd przetwarzania: ${error}`);
  return json({
    ok: true,
    status,
    received: runStats.received,
    newJobs: runStats.newCount,
    baseline,
    notificationsSent: pushStats.sent,
    notificationsFailed: pushStats.failed,
  });
}

// Radar Pracy – Cloudflare Worker: API + serwowanie PWA (Workers Static Assets).

import { HttpError, json } from './util.js';
import { checkIngestAuth, checkSameOrigin, handleLogin, handleLogout, isAuthenticated } from './auth.js';
import { handleIngest } from './ingest.js';
import {
  getDiag, getFilter, getJob, getPushKey, getSources, listJobs, patchJob, pushTest, putFilter, subscribe, unsubscribe,
} from './api.js';

async function route(request, env) {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;

  if (path === '/api/health') return json({ ok: true, app: 'radar-pracy' });

  if (path === '/api/ingest' && method === 'POST') {
    await checkIngestAuth(request, env);
    return handleIngest(request, env);
  }

  if (path === '/api/login' && method === 'POST') {
    checkSameOrigin(request);
    return handleLogin(request, env);
  }

  // Wszystko poniżej wymaga zalogowania.
  if (!(await isAuthenticated(request, env))) throw new HttpError(401, 'Zaloguj się');
  if (method !== 'GET') checkSameOrigin(request);

  if (path === '/api/logout' && method === 'POST') return handleLogout(request);
  if (path === '/api/me' && method === 'GET') return json({ ok: true });
  if (path === '/api/jobs' && method === 'GET') return listJobs(url, env);

  const jobMatch = /^\/api\/jobs\/(\d+)$/.exec(path);
  if (jobMatch) {
    const id = Number(jobMatch[1]);
    if (method === 'GET') return getJob(id, env);
    if (method === 'PATCH') return patchJob(id, request, env);
  }

  if (path === '/api/filter' && method === 'GET') return getFilter(env);
  if (path === '/api/filter' && method === 'PUT') return putFilter(request, env);
  if (path === '/api/sources' && method === 'GET') return getSources(env);
  if (path === '/api/diag' && method === 'GET') return getDiag(env);
  if (path === '/api/push/key' && method === 'GET') return getPushKey(env);
  if (path === '/api/push/subscribe' && method === 'POST') return subscribe(request, env);
  if (path === '/api/push/unsubscribe' && method === 'POST') return unsubscribe(request, env);
  if (path === '/api/push/test' && method === 'POST') return pushTest(request, env);

  throw new HttpError(404, 'Nie znaleziono');
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/')) return env.ASSETS.fetch(request);
    try {
      return await route(request, env);
    } catch (err) {
      if (err instanceof HttpError) return json({ error: err.message }, err.status);
      // Bez szczegółów żądania w logach (mogą zawierać dane prywatne).
      console.error('Błąd API:', path(url), err && err.message ? err.message : 'nieznany');
      return json({ error: 'Błąd serwera' }, 500);
    }
  },
};

function path(url) {
  return url.pathname.replace(/\/\d+$/, '/:id');
}

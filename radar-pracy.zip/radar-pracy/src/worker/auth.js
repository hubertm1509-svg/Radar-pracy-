// Logowanie jednego użytkownika: hasło z sekretu APP_PASSWORD,
// sesja w podpisanym ciasteczku HttpOnly. Sekret podpisu jest tworzony
// automatycznie i trzymany w D1 (nie trzeba go konfigurować).

import { b64uDecode, b64uEncode } from './webpush.js';
import { HttpError, getOrCreateSetting, getSetting, json, nowIso, readJson, secretsEqual, setSetting, timingSafeEqualBytes } from './util.js';

const COOKIE = 'rp_session';
const SESSION_DAYS = 90;
const MAX_FAILS = 8;
const LOCK_MINUTES = 15;

async function sessionKey(db) {
  const secret = await getOrCreateSetting(db, 'session_secret', () => b64uEncode(crypto.getRandomValues(new Uint8Array(32))));
  return crypto.subtle.importKey('raw', b64uDecode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
}

async function sign(db, data) {
  const key = await sessionKey(db);
  return new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(data)));
}

export async function createSessionCookie(db, secure) {
  const exp = Date.now() + SESSION_DAYS * 86400_000;
  const payload = b64uEncode(new TextEncoder().encode(JSON.stringify({ exp, v: 1 })));
  const token = `${payload}.${b64uEncode(await sign(db, payload))}`;
  return `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_DAYS * 86400}${secure ? '; Secure' : ''}`;
}

export function clearSessionCookie(secure) {
  return `${COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure ? '; Secure' : ''}`;
}

function readCookie(request) {
  const header = request.headers.get('cookie') || '';
  for (const part of header.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === COOKIE) return v.join('=');
  }
  return null;
}

export async function isAuthenticated(request, env) {
  const token = readCookie(request);
  if (!token || !token.includes('.')) return false;
  const [payload, sig] = token.split('.');
  let given;
  try { given = b64uDecode(sig); } catch { return false; }
  const expected = await sign(env.DB, payload);
  if (!timingSafeEqualBytes(given, expected)) return false;
  try {
    const data = JSON.parse(new TextDecoder().decode(b64uDecode(payload)));
    return typeof data.exp === 'number' && data.exp > Date.now();
  } catch {
    return false;
  }
}

export async function handleLogin(request, env) {
  if (!env.APP_PASSWORD || String(env.APP_PASSWORD).length < 10) {
    throw new HttpError(503, 'Hasło aplikacji nie jest skonfigurowane (sekret APP_PASSWORD, min. 10 znaków).');
  }
  const db = env.DB;
  const raw = await getSetting(db, 'login_failures');
  const state = raw ? JSON.parse(raw) : { count: 0, lockedUntil: 0 };
  if (state.lockedUntil > Date.now()) {
    throw new HttpError(429, `Za dużo nieudanych prób. Spróbuj za ${Math.ceil((state.lockedUntil - Date.now()) / 60000)} min.`);
  }
  const body = await readJson(request, 10_000);
  const ok = await secretsEqual(body.password, env.APP_PASSWORD);
  if (!ok) {
    state.count += 1;
    if (state.count >= MAX_FAILS) {
      state.count = 0;
      state.lockedUntil = Date.now() + LOCK_MINUTES * 60000;
    }
    await setSetting(db, 'login_failures', JSON.stringify(state));
    throw new HttpError(401, 'Nieprawidłowe hasło');
  }
  await setSetting(db, 'login_failures', JSON.stringify({ count: 0, lockedUntil: 0 }));
  await setSetting(db, 'last_login_at', nowIso());
  const secure = new URL(request.url).protocol === 'https:';
  return json({ ok: true }, 200, { 'Set-Cookie': await createSessionCookie(db, secure) });
}

export function handleLogout(request) {
  const secure = new URL(request.url).protocol === 'https:';
  return json({ ok: true }, 200, { 'Set-Cookie': clearSessionCookie(secure) });
}

export async function checkIngestAuth(request, env) {
  const secret = env.INGEST_SECRET;
  if (!secret || String(secret).length < 24) {
    throw new HttpError(503, 'INGEST_SECRET nie jest skonfigurowany (min. 24 znaki).');
  }
  const header = request.headers.get('authorization') || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!(await secretsEqual(token, secret))) throw new HttpError(401, 'Brak dostępu');
}

// Ochrona przed CSRF dla żądań zmieniających dane.
export function checkSameOrigin(request) {
  const origin = request.headers.get('origin');
  if (origin && origin !== new URL(request.url).origin) throw new HttpError(403, 'Niedozwolone źródło żądania');
  const ct = request.headers.get('content-type') || '';
  if (!ct.includes('application/json')) throw new HttpError(415, 'Wymagany JSON');
}

# Radar Pracy

Osobista aplikacja (PWA na iPhone) do szybkiego wykrywania nowych ofert pracy w promieniu
30 km od Niechobrza i wysyłania powiadomień. Koszt działania: 0 zł.

```
GitHub Actions (co ~30 min)          Cloudflare Worker + D1               iPhone (PWA)
 sync/run.js ── RSS Rzeszowiak ──►  POST /api/ingest ── nowa oferta ──►  powiadomienie
   normalizacja, miejscowość,        zapis, deduplikacja, filtr,          → oferta w aplikacji
   odległość                         Web Push (VAPID)                     → oryginalne ogłoszenie
```

- **Wdrożenie:** [docs/WDROZENIE.md](docs/WDROZENIE.md)
- **Decyzje, limity i koszty:** [docs/DECYZJE.md](docs/DECYZJE.md)
- **Źródła ofert:** [docs/ZRODLA.md](docs/ZRODLA.md)
- **Testy i stan gotowości:** [docs/TESTY.md](docs/TESTY.md)

## Struktura

| Ścieżka | Zawartość |
|---|---|
| `src/worker/` | API: logowanie, ingest, oferty, filtr, źródła, diagnostyka, Web Push |
| `src/shared/` | normalizacja tekstu, słownik miejscowości, filtr (wspólne dla Workera i synchronizatora) |
| `sync/` | synchronizator i adapter Rzeszowiak.pl |
| `public/` | PWA: interfejs, service worker, manifest, ikony |
| `migrations/` | schemat bazy D1 |
| `test/` | testy jednostkowe, test end-to-end, fixture'y RSS |
| `.github/workflows/` | `sync.yml` (synchronizacja), `deploy.yml` (wdrożenie) |

## Polecenia (dla osób z Node 20+)

```bash
npm install
npm test            # testy jednostkowe
npm run test:e2e    # pełny przepływ na lokalnym SQLite
npm run lint
npm run sync:dry    # pobranie prawdziwego RSS bez wysyłki
APP_PASSWORD=haslo-testowe INGEST_SECRET=$(openssl rand -hex 20) node test/support/server.mjs  # podgląd lokalny
```

## Stan faz

- [x] Faza 0 – weryfikacja dokumentacji, stos, macierz źródeł, limity
- [x] Faza 1 – PWA, Worker API, D1 + migracje, logowanie, adapter RSS, lista ofert
- [x] Faza 2 – Web Push, service worker, diagnostyka, deduplikacja, idempotencja (test iPhone: użytkownik)
- [~] Faza 3 – promień, statusy, zapisane, notatki, filtr słów: **gotowe**; pełny zestaw 18 filtrów,
  ranking punktowy i Nominatim: **następny krok**
- [ ] Faza 4–7 – alerty e-mail, ePraca, trudne źródła, statystyki, eksport, przypomnienia

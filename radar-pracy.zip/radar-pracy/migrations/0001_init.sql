-- Radar Pracy – schemat początkowy (Cloudflare D1 / SQLite)

CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

-- Rejestr i stan źródeł ofert
CREATE TABLE source_state (
  source TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  integration TEXT NOT NULL CHECK (integration IN ('active', 'official_alert', 'manual_source', 'unsupported', 'requires_configuration')),
  method TEXT,
  homepage TEXT,
  manual_url TEXT,
  notes TEXT,
  last_attempt_at TEXT,
  last_success_at TEXT,
  last_error TEXT,
  last_count INTEGER NOT NULL DEFAULT 0,
  consecutive_errors INTEGER NOT NULL DEFAULT 0,
  baseline_done INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source TEXT NOT NULL REFERENCES source_state(source),
  source_id TEXT NOT NULL,
  source_url TEXT NOT NULL,
  canonical_url TEXT NOT NULL,
  title TEXT NOT NULL,
  title_from_slug INTEGER NOT NULL DEFAULT 0,
  company TEXT,
  location_text TEXT,
  latitude REAL,
  longitude REAL,
  distance_km REAL,
  location_approx INTEGER NOT NULL DEFAULT 0,
  location_status TEXT NOT NULL DEFAULT 'wymaga_sprawdzenia' CHECK (location_status IN ('ok', 'wymaga_sprawdzenia')),
  salary_min REAL,
  salary_max REAL,
  salary_type TEXT,
  contract_type TEXT,
  work_mode TEXT,
  description_summary TEXT,
  published_at TEXT,
  first_seen_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  contact_phone TEXT,
  contact_email TEXT,
  requirements TEXT,
  raw_fingerprint TEXT NOT NULL,
  search_text TEXT NOT NULL,
  duplicate_of INTEGER REFERENCES jobs(id),
  is_read INTEGER NOT NULL DEFAULT 0,
  is_saved INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'nowa' CHECK (status IN ('nowa', 'przeczytana', 'aplikowalem', 'rozmowa', 'odrzucona', 'zatrudniony', 'pominieta')),
  baseline INTEGER NOT NULL DEFAULT 0,
  UNIQUE (source, source_id)
);
CREATE UNIQUE INDEX idx_jobs_canonical ON jobs (canonical_url);
CREATE INDEX idx_jobs_fingerprint ON jobs (raw_fingerprint);
CREATE INDEX idx_jobs_seen ON jobs (source, first_seen_at);
CREATE INDEX idx_jobs_order ON jobs (published_at DESC, id DESC);
CREATE INDEX idx_jobs_status ON jobs (status);
CREATE INDEX idx_jobs_saved ON jobs (is_saved) WHERE is_saved = 1;

-- Wszystkie adresy źródłowe danej oferty
CREATE TABLE job_sources (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL REFERENCES jobs(id),
  source TEXT NOT NULL,
  source_url TEXT NOT NULL,
  first_seen_at TEXT NOT NULL,
  UNIQUE (source, source_url)
);
CREATE INDEX idx_job_sources_job ON job_sources (job_id);

CREATE TABLE filters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  config TEXT NOT NULL,
  is_default INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);

CREATE TABLE push_subscriptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  endpoint TEXT NOT NULL UNIQUE,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  user_agent TEXT,
  created_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  failures INTEGER NOT NULL DEFAULT 0,
  last_error TEXT
);

CREATE TABLE notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER REFERENCES jobs(id),
  subscription_id INTEGER NOT NULL REFERENCES push_subscriptions(id),
  filter_id INTEGER REFERENCES filters(id),
  kind TEXT NOT NULL CHECK (kind IN ('job', 'test', 'summary', 'summarized')),
  status TEXT NOT NULL CHECK (status IN ('pending', 'sent', 'failed', 'expired', 'summarized')),
  attempts INTEGER NOT NULL DEFAULT 0,
  http_status INTEGER,
  created_at TEXT NOT NULL,
  sent_at TEXT
);
-- Jedna oferta = najwyżej jedno powiadomienie na subskrypcję i filtr
CREATE UNIQUE INDEX idx_notifications_once ON notifications (job_id, subscription_id, filter_id) WHERE job_id IS NOT NULL;
CREATE INDEX idx_notifications_status ON notifications (status, created_at);

-- Historia zmian statusu oferty
CREATE TABLE application_status (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL REFERENCES jobs(id),
  status TEXT NOT NULL,
  changed_at TEXT NOT NULL
);
CREATE INDEX idx_application_status_job ON application_status (job_id);

CREATE TABLE notes (
  job_id INTEGER PRIMARY KEY REFERENCES jobs(id),
  note TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE sync_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id TEXT NOT NULL UNIQUE,
  trigger TEXT,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  status TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running', 'ok', 'partial', 'error')),
  sources_ok INTEGER NOT NULL DEFAULT 0,
  sources_failed INTEGER NOT NULL DEFAULT 0,
  items_received INTEGER NOT NULL DEFAULT 0,
  items_new INTEGER NOT NULL DEFAULT 0,
  notifications_sent INTEGER NOT NULL DEFAULT 0,
  error TEXT
);

CREATE TABLE geocoding_cache (
  query TEXT PRIMARY KEY,
  name TEXT,
  latitude REAL,
  longitude REAL,
  distance_km REAL,
  provider TEXT NOT NULL,
  created_at TEXT NOT NULL
);

-- Źródła: stan z weryfikacji (listopad 2026), opis w docs/ZRODLA.md
INSERT INTO source_state (source, name, integration, method, homepage, manual_url, notes) VALUES
 ('rzeszowiak', 'Rzeszowiak.pl', 'active', 'RSS (3 kanały działu Praca)', 'https://www.rzeszowiak.pl', 'https://www.rzeszowiak.pl/rss/', 'Oficjalne kanały RSS, 200 ostatnich ogłoszeń na kanał.'),
 ('pracuj', 'Pracuj.pl', 'official_alert', 'Alert e-mail w serwisie', 'https://www.pracuj.pl', 'https://www.pracuj.pl/praca/rzeszow;wp?rd=30', 'Brak publicznego API/RSS. Ustaw alert e-mail w serwisie.'),
 ('praca_pl', 'Praca.pl', 'manual_source', 'Ręcznie', 'https://www.praca.pl', 'https://www.praca.pl', 'Brak potwierdzonego RSS/API.'),
 ('jobs_pl', 'JOBS.pl', 'manual_source', 'Ręcznie', 'https://www.jobs.pl', 'https://www.jobs.pl', 'Brak potwierdzonego RSS/API.'),
 ('olx', 'OLX Praca', 'official_alert', 'Obserwowane wyszukiwanie w aplikacji OLX', 'https://www.olx.pl', 'https://www.olx.pl/praca/rzeszow/?search%5Bdist%5D=30', 'API OLX nie pozwala czytać cudzych ogłoszeń.'),
 ('epraca', 'ePraca (CBOP)', 'requires_configuration', 'WebService SOAP CBOP', 'https://oferty.praca.gov.pl', 'https://oferty.praca.gov.pl', 'Wymaga nazwy partnera nadanej przez ministerstwo; działa 17:00–07:00.'),
 ('pup_rzeszow', 'PUP Rzeszów', 'requires_configuration', 'Przez ePraca (CBOP)', 'https://rzeszow.praca.gov.pl', 'https://oferty.praca.gov.pl', 'Oferty PUP są w bazie ePraca.'),
 ('aplikuj', 'Aplikuj.pl', 'manual_source', 'Ręcznie', 'https://www.aplikuj.pl', 'https://www.aplikuj.pl', 'Brak potwierdzonego RSS/API.'),
 ('indeed', 'Indeed', 'official_alert', 'Alert e-mail Indeed', 'https://pl.indeed.com', 'https://pl.indeed.com/jobs?l=Rzesz%C3%B3w&radius=25', 'Publiczne API wycofane.'),
 ('lento', 'Lento.pl', 'manual_source', 'Ręcznie', 'https://www.lento.pl', 'https://www.lento.pl', 'Brak potwierdzonego RSS/API.'),
 ('kariery', 'Strony karier pracodawców', 'requires_configuration', 'Feedy systemów rekrutacyjnych (ATS)', NULL, NULL, 'Wymaga listy pracodawców z oficjalnym feedem.'),
 ('lokalne', 'Lokalne portale', 'requires_configuration', 'RSS do weryfikacji (np. e-rzeszowiak.pl)', 'https://e-rzeszowiak.pl', 'https://e-rzeszowiak.pl', 'Do sprawdzenia regulamin i RSS.');
